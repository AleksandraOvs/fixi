<?php 
/* Template Name: Блог */
get_header(); 
?>

<div class="blog content">
    <div class="container">

        <?php breadcrumbs('Блог') ?>

        <h1>Блог</h1>
        <div class="h1__sub">
            Практические советы и другая полезная информация
        </div>

        <?php get_template_part( 'loop' ); ?>

    </div>
</div>

<?php get_footer(); ?>