<div class="problem-icons m-100">
    <div class="container">
        <div class="card">
            <h2>
                мы справимся неисправностями любой сложности! 
                <br><span>какая неисправность у вашего телефона?</span>
            </h2>
            
            <div class="problem-icons__list">

                <div class="row auto-h">
                    <div class="col-4">
                        <div class="problem-card" data-toggle="modal" data-target="#lead-modal">
                            <div class="problem-card__icon">
                                <img src="/img/problems/8.png" alt="">
                            </div>
                            <div class="problem-card__title">
                                Треснул экран или тачскрин
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="problem-card__robot">
                            <div class="problem-card__icon">
                                <img src="/img/problems/bot.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
</div>