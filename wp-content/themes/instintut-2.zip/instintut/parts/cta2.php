<?php
/**
 * Блок выбора устройств и формы на главной странице
 * С реальными данными моделей и симптомов
 */

// Получаем категории устройств
$device_categories = get_posts(array(
    'post_type' => 'device',
    'posts_per_page' => -1,
    'orderby' => 'menu_order',
    'order' => 'ASC',
));

// Собираем модели по категориям + симптомы
$models_by_device = [];
$symptoms_by_device = [];
$all_models_data = [];

foreach ($device_categories as $category) {
    $device_id = $category->ID;
    $device_slug = sanitize_title($category->post_title);
    
    // Получаем связанные модели через ACF Relationship
    $related_models = get_field('models', $device_id);
    
    if ($related_models && is_array($related_models)) {
        $models_by_device[$device_slug] = [];
        $symptoms_by_device[$device_slug] = [];
        
        foreach ($related_models as $model_post) {
            $model_id = $model_post->ID;
            $model_title = get_the_title($model_id);
            
            $model_data = [
                'id' => $model_id,
                'title' => $model_title,
                'slug' => sanitize_title($model_title),
                'url' => get_permalink($model_id)
            ];
            
            $models_by_device[$device_slug][] = $model_data;
            
            // Добавляем в общий массив
            if (!isset($all_models_data[$model_data['slug']])) {
                $all_models_data[$model_data['slug']] = $model_data;
            }
            
            // Получаем симптомы из ACF repeater поля "prices"
            $prices = get_field('prices', $model_id);
            
            if ($prices && is_array($prices)) {
                foreach ($prices as $price_item) {
                    if (isset($price_item['problem'])) {
                        $problem = sanitize_text_field($price_item['problem']);
                        
                        // Добавляем уникальные проблемы для этого типа устройства
                        if (!in_array($problem, $symptoms_by_device[$device_slug])) {
                            $symptoms_by_device[$device_slug][] = $problem;
                        }
                    }
                }
            }
        }
        
        // Сортируем симптомы
        if (!empty($symptoms_by_device[$device_slug])) {
            sort($symptoms_by_device[$device_slug]);
        }
    }
}

// Первая категория по умолчанию
$first_device_slug = array_key_first($models_by_device);
?>

<div class="cta2 m-100">
    <div class="container">
        <div class="cta2__in">
            <div class="row">
                <div class="col-4">
                    <h2>
                        Найди 
                        <br>неисправность 
                        <br>по симптомам
                    </h2>
                </div>
                <div class="col-8">
                    <div class="cta__form">
                        <form class="cta2-search-form" method="GET" action="https://t.me">
                            
                            <!-- Вид устройства -->
                            <select class="search-form__input" id="cta2-device-type" name="device_type" required>
                                <option value="" disabled selected>Вид устройства</option>
                                <?php foreach ($device_categories as $category): 
                                    $device_slug = sanitize_title($category->post_title);
                                ?>
                                    <option value="<?php echo esc_attr($device_slug); ?>">
                                        <?php echo esc_html($category->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            
                            <!-- Модель -->
                            <select class="search-form__input" id="cta2-device-model" name="device_model" required>
                                <option value="" selected>Модель</option>
                                <?php 
                                // Выводим модели первой категории
                                if ($first_device_slug && isset($models_by_device[$first_device_slug])):
                                    foreach ($models_by_device[$first_device_slug] as $model):
                                ?>
                                    <option value="<?php echo esc_attr($model['slug']); ?>" data-device="<?php echo esc_attr($first_device_slug); ?>">
                                        <?php echo esc_html($model['title']); ?>
                                    </option>
                                <?php 
                                    endforeach;
                                endif;
                                ?>
                            </select>
                            
                            <!-- Что сломалось -->
                            <select class="search-form__input" id="cta2-device-problem" name="device_problem" required>
                                <option value="" selected>Что сломалось</option>
                                <?php 
                                // Выводим симптомы первой категории
                                if ($first_device_slug && isset($symptoms_by_device[$first_device_slug])):
                                    foreach ($symptoms_by_device[$first_device_slug] as $symptom):
                                ?>
                                    <option value="<?php echo esc_attr(sanitize_title($symptom)); ?>" data-device="<?php echo esc_attr($first_device_slug); ?>">
                                        <?php echo esc_html($symptom); ?>
                                    </option>
                                <?php 
                                    endforeach;
                                endif;
                                ?>
                            </select>
                            
                            <button type="submit" class="btn btn--orange search-form__btn">
                                Узнать причину
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Используем те же данные из первой формы
    const modelsByDevice = <?php echo json_encode($models_by_device, JSON_UNESCAPED_UNICODE); ?>;
    const symptomsByDevice = <?php echo json_encode($symptoms_by_device, JSON_UNESCAPED_UNICODE); ?>;
    
    // === ФУНКЦИИ ДЛЯ ВТОРОЙ ФОРМЫ (CTA2) ===
    
    function updateCta2ModelsSelect(deviceSlug) {
        const $modelSelect = $('#cta2-device-model');
        const models = modelsByDevice[deviceSlug] || [];
        
        $modelSelect.html('<option value="" selected>Выберите модель</option>');
        
        if (models.length > 0) {
            models.forEach(function(model) {
                const option = $('<option>')
                    .val(model.slug)
                    .text(model.title)
                    .attr('data-device', deviceSlug);
                $modelSelect.append(option);
            });
        } else {
            $modelSelect.html('<option value="" disabled>Модели не найдены</option>');
        }
    }
    
    function updateCta2ProblemsSelect(deviceSlug) {
        const $problemSelect = $('#cta2-device-problem');
        const symptoms = symptomsByDevice[deviceSlug] || [];
        
        $problemSelect.html('<option value="" selected>Что сломалось</option>');
        
        if (symptoms.length > 0) {
            symptoms.forEach(function(symptom) {
                const symptomSlug = symptom.toLowerCase()
                    .replace(/[^a-zа-яё0-9\s]/gi, '')
                    .replace(/\s+/g, '-');
                    
                const option = $('<option>')
                    .val(symptomSlug)
                    .text(symptom)
                    .attr('data-device', deviceSlug);
                $problemSelect.append(option);
            });
        } else {
            $problemSelect.html('<option value="" disabled>Проблемы не найдены</option>');
        }
    }
    
    // === ОБРАБОТЧИКИ ДЛЯ ВТОРОЙ ФОРМЫ ===
    
    $('#cta2-device-type').on('change', function() {
        const selectedDevice = $(this).val();
        
        if (selectedDevice) {
            updateCta2ModelsSelect(selectedDevice);
            updateCta2ProblemsSelect(selectedDevice);
            
            // Синхронизируем с первой формой (опционально)
            $('#device-type').val(selectedDevice).trigger('change');
        }
    });
    
    // === ВАЛИДАЦИЯ ВТОРОЙ ФОРМЫ ===
    $('.cta2-search-form').on('submit', function(e) {
        const deviceType = $('#cta2-device-type').val();
        const deviceModel = $('#cta2-device-model').val();
        const deviceProblem = $('#cta2-device-problem').val();
        
        if (!deviceType || !deviceModel || !deviceProblem) {
            e.preventDefault();
            alert('Пожалуйста, заполните все поля формы');
            return false;
        }
    });
});
</script>