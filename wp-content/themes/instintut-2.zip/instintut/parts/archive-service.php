<div class="container">
    <?php get_template_part('parts/services-list'); ?>
</div>

<?php get_template_part('parts/callback'); ?>

<div class="white-wrapper m-100">

    <?php get_template_part('parts/faq'); ?>

    <?php get_template_part('parts/features'); ?>

    <?php get_template_part('parts/team'); ?>

    <?php get_template_part('parts/reviews'); ?>

</div>

<?php get_template_part('parts/problems'); ?>

<div class="cta__wrapper">
    <?php get_template_part('parts/diagnostic'); ?>
</div>

<?php get_template_part('parts/contacts'); ?>

