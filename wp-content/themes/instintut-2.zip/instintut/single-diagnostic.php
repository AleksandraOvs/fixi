<?php
get_header();

$h1 = get_field('h1') ? get_field('h1') : $post->post_title;

$banner_img = get_field('image') ? get_field('image')['sizes']['large'] : '/wp-content/uploads/2026/01/3721592-2.png';
$banner_title = get_field('title') ?: '';
$banner_sub = get_field('sub') ?: '';

$solutions = get_field('solutions') ?: [];
?>

<div class="bg-wrapper p-bottom-0">
    <div class="services-hero__in m-40">
        <div class="container">
            <div class="services-hero">
        
                <div class="services-hero__content">

                    <?php breadcrumbs($post->post_title); ?>
                    
                    <h1>
                        <span>
                            <?= $h1 ?>
                        </span>
                        <br>поможем это исправить
                    </h1>
                    
                    <?php if ($banner_sub) : ?>
                        <div class="services-hero__sub">
                            <?= $banner_sub ?>
                        </div>
                    <?php endif ?>
                    
                    <div class="services-hero__action">
                        <a href="#" data-toggle="modal" data-target="#lead-modal" class="btn">Забронировать время</a>
                    </div>
                </div>
        
                <div class="services-hero__img">
        
                    <div class="services-hero__img-dec">
                        <img src="/img/dec.svg" alt="">
                    </div>
        
                    <img src="<?= $banner_img ?>" alt="" class="services__img">
                </div>
        
            </div>
        </div>
    </div>

    <?php if (count($solutions)) : ?>
        <div class="diagnostic m-100">
            <div class="container">
                <div class="card">
                    <h2>
                        Возможные решения<br> при данной неисправности
                        <br>
                        <span>
                            выберите подходящий
                        </span>
                    </h2>

                    <div class="solutions-list">
                        
                        <?php foreach ($solutions as $item) : ?>

                            <div class="sol-item">

                                <div class="solution-card" style="--p: <?= $item['probability'] ?>">
                                    <div class="icon-wrapper">
                                        <div class="icon-base">
                                            <div class="chart-value"><?= $item['probability'] ?><span>%</span></div>
                                            
                                            <div class="bars-container">
                                                <div class="bar" style="--h: 40%; --limit: 0">
                                                    <div class="bar-layer layer-yellow"></div><div class="bar-layer layer-blue"></div>
                                                </div>
                                                <div class="bar" style="--h: 60%; --limit: 49">
                                                    <div class="bar-layer layer-yellow"></div><div class="bar-layer layer-blue"></div>
                                                </div>
                                                <div class="bar" style="--h: 80%; --limit: 74">
                                                    <div class="bar-layer layer-yellow"></div><div class="bar-layer layer-blue"></div>
                                                </div>
                                                <div class="bar" style="--h: 100%; --limit: 99">
                                                    <div class="bar-layer layer-yellow"></div><div class="bar-layer layer-blue"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="sol-item__content">
                                    <div class="sol-item__title">
                                        <?= $item['title'] ?>
                                    </div>
                                    <div class="sol-item__text">
                                        <?= $item['short']  ?>
                                    </div>
                                    <div class="sol-item__price">
                                        Cтоимость ремонта от: <?= $item['price'] ?> руб.
                                    </div>
                                </div>

                            </div>

                        <?php endforeach ?>

                    </div>

                    <div class="solution-list__sub">
                        *  Более точную стоимость уточняйте по телефону 47-81-80 или в WhatsApp/Telegram +7 (908) 119-13-74.
                    </div>
                </div>
            </div>
        </div>
    <?php endif ?>

    <?php get_template_part('parts/callback'); ?>

    <?php if (get_field('text')) : ?>
        <div class="p-100">
            <div class="container">
                <div class="card">
                    <h2>
                        <?= get_field('text_title') ?>
                    </h2>
                    <div class="text-block">
                        <?= get_field('text') ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif ?>

    <div class="white-wrapper m-100">

        <?php get_template_part('parts/reviews', null, ['css_class' => 'padd-0']); ?>

        <?php get_template_part('parts/team'); ?>

        <div class="p-100">
            <?php get_template_part('parts/steps'); ?>
        </div>

        <?php get_template_part('parts/contacts'); ?>

    </div>

    <?php get_template_part('parts/cta'); ?>

</div>


<?php get_footer(); ?>