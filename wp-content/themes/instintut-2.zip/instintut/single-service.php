<?php
get_header();

$h1_sub = get_field('h1_sub') ?: 'Fixibot в Омске';
$h1 = get_field('h1') ? get_field('h1') : $post->post_title;

$banner_sub = get_field('sub') ?: '';

$banner_img = get_field('image') ? get_field('image')['sizes']['large'] : '/wp-content/uploads/2026/01/group-243.png';

$is_archive = get_field('is_archive') ?: false;
?>

<div class="bg-wrapper p-bottom-0">

    <div class="services-hero__in">
        <div class="container">

            <?php breadcrumbs($post->post_title); ?>
            
            <div class="services-hero">
        
                <div class="services-hero__content">
                    <h1>
                        <span>
                            <?= $h1_sub ?>
                        </span>
                        <br><?= $h1 ?>
                    </h1>
                    
                    <?php if ($banner_sub) : ?>
                        <div class="services-hero__sub">
                            <?= $banner_sub ?>
                        </div>
                    <?php endif ?>
                    
                    <div class="services-hero__action">
                        <a href="#" data-toggle="modal" data-target="#lead-modal" class="btn">Забронировать время</a>
                    </div>
                </div>
        
                <div class="services-hero__img">
                
                    <div class="services-hero__img-dec">
                        <img src="/img/dec.svg" alt="">
                    </div>
                
                    <img src="<?= $banner_img ?>" alt="" class="services__img">
                </div>
        
            </div>
        </div>
    </div>

    <?php if ($is_archive) : ?>

        <?php get_template_part('parts/archive-service'); ?>

    <?php else : ?>

        <?php get_template_part('parts/service'); ?>

    <?php endif ?>

    <?php if (get_field('text')) : ?>
        <div class="p-100">
            <div class="container">
                <div class="card">
                    <h2>
                        <?= get_field('text_title') ?>
                    </h2>
                    <div class="text-block">
                        <?= get_field('text') ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif ?>

</div>

<?php get_footer(); ?>