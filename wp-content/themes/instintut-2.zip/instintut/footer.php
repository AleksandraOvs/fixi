<footer>
    <div class="container">
        <div class="footer__in">
            <div class="footer__col">
                <div class="footer__logo">
                    <img src="/img/logo.svg" alt="">
                </div>
                <div class="footer__address-mail">
                    <div class="footer__address">
                        г. Москва, <br>ул. 4-я Магистральная, дом 5 с1
                    </div>
                    <div class="footer__mail">
                        <a href="mailto:info@ruki-iz-plech.ru">
                            info@ruki-iz-plech.ru
                        </a>
                    </div>
                </div>
            </div>
            <div class="footer__col footer__col_nav">
                <ul class="footer__list">
                    <li><a href="/#about">О нас</a></li>
                    <li><a href="">Гарантия</a></li>
                    <li><a href="">Акции</a></li>
                    <li><a href="">Доставка</a></li>
                    <li><a href="/#reviews">Отзывы</a></li>
                    <li><a href="">Вакансии</a></li>
                </ul>
                <ul class="footer__list footer__list_last">
                    <li><a href="/service/remont-telefonov/">Ремонт телефонов</a></li>
                    <li><a href="/service/remont-drugix-ustrojstv/remont-computerov/">Ремонт компьютеров</a></li>
                    <li><a href="/service/remont-komputerov/remont-noutbukov/">Ремонт ноутбуков</a></li>
                    <li><a href="/service/remont-drugix-ustrojstv/remont-samokatov/">Ремонт самокатов</a></li>
                    <li><a href="/service/remont-drugix-ustrojstv/remont-samokatov/">Ремонт квадрокоптеров</a></li>
                </ul>
            </div>
            <div class="footer__col">
                <div class="footer__phone-sub">
                    Единый контактный центр
                </div>
                <div class="footer__call">
                    <a href="tel:<?= get_field('phone', 'option') ?>" class="btn">
                        <?= get_field('phone', 'option') ?>
                    </a>
                </div>
                <div class="footer__mail_last">
                    <a href="mailti:<?= get_field('email', 'option') ?>">
                        <?= get_field('email', 'option') ?>
                    </a>
                </div>
                <div class="footer__pay-title">
                    Способы оплаты
                </div>
                <div class="footer__pays">
                    <img src="/img/pays.svg" alt="">
                </div>
            </div>
        </div>
        <div class="footer__bottom">
            <div class="footer__social-block">
                <div class="footer__social-title">
                    FIXIBOT в соц. сетях
                </div>
                <div class="footer__social">
                    <a href="<?= get_field('vk', 'option') ?>" target="_blank">
                        <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="41.8883" height="41.8883" rx="20.9442" fill="#008EE9"/>
                        <g clip-path="url(#clip0_4001_415)">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.58984 14.1631C7.81098 24.3694 13.1181 30.503 22.4227 30.503H22.95V24.6638C26.369 24.991 28.9546 27.3953 29.9922 30.503H34.8231C33.4963 25.8578 30.0092 23.2899 27.8319 22.3085C30.0092 21.0982 33.071 18.154 33.8025 14.1631H29.4139C28.4613 17.4016 25.6376 20.3458 22.95 20.6238V14.1631H18.5614V25.4816C15.8398 24.8274 12.4037 21.6543 12.2506 14.1631H7.58984Z" fill="white"/>
                        </g>
                        <defs>
                        <clipPath id="clip0_4001_415">
                        <rect width="26.7098" height="19.1177" fill="white" transform="translate(7.58984 11.3857)"/>
                        </clipPath>
                        </defs>
                        </svg>
                    </a>
                    <a href="<?= get_field('wa', 'option') ?>" target="_blank">
                        <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="41.7746" height="41.8883" rx="20.8873" fill="#008EE9"/>
                        <path d="M9.875 32.2437L11.4635 26.4407C10.4833 24.742 9.96822 22.8165 9.96916 20.842C9.97198 14.6689 14.9954 9.64551 21.1675 9.64551C24.1627 9.64645 26.9743 10.8131 29.0891 12.9298C31.203 15.0465 32.3668 17.8599 32.3658 20.8523C32.363 27.0263 27.3396 32.0497 21.1675 32.0497C19.2937 32.0488 17.4473 31.5789 15.8117 30.6863L9.875 32.2437ZM16.0867 28.659C17.6648 29.5959 19.1713 30.1571 21.1637 30.1581C26.2935 30.1581 30.4723 25.983 30.4751 20.8504C30.477 15.7075 26.318 11.5381 21.1713 11.5362C16.0377 11.5362 11.8618 15.7112 11.8599 20.8429C11.8589 22.9379 12.4728 24.5066 13.5039 26.1478L12.5632 29.5827L16.0867 28.659ZM26.8086 23.5142C26.7389 23.3974 26.5524 23.3278 26.2719 23.1875C25.9922 23.0472 24.6165 22.3702 24.3595 22.2769C24.1034 22.1837 23.9169 22.1366 23.7296 22.4172C23.5431 22.6969 23.0064 23.3278 22.8435 23.5142C22.6806 23.7006 22.5168 23.7242 22.2371 23.5839C21.9575 23.4436 21.0554 23.1489 19.9867 22.195C19.1553 21.4531 18.5932 20.5369 18.4303 20.2563C18.2674 19.9766 18.4133 19.825 18.5527 19.6857C18.6789 19.5605 18.8323 19.359 18.9726 19.1951C19.1148 19.0332 19.161 18.9164 19.2551 18.729C19.3483 18.5426 19.3022 18.3788 19.2316 18.2385C19.161 18.0991 18.6017 16.7216 18.3691 16.1613C18.1412 15.6161 17.9105 15.6896 17.7392 15.6811L17.2025 15.6717C17.016 15.6717 16.7128 15.7414 16.4567 16.022C16.2006 16.3026 15.4775 16.9786 15.4775 18.3562C15.4775 19.7337 16.4803 21.0642 16.6196 21.2506C16.7599 21.437 18.5922 24.2637 21.3991 25.4755C22.0667 25.7637 22.5884 25.936 22.9942 26.065C23.6646 26.2778 24.2747 26.2476 24.7568 26.1761C25.2945 26.096 26.4122 25.4991 26.6457 24.8456C26.8792 24.1912 26.8792 23.6309 26.8086 23.5142Z" fill="white"/>
                        </svg>
                    </a>
                    <a href="<?= get_field('tg', 'option') ?>" target="_blank">
                        <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <g clip-path="url(#clip0_4021_422)">
                            <rect x="8.71875" y="9.96289" width="23.6719" height="24.8887" fill="white" />
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M41.6663 20.8332C41.6663 32.339 32.339 41.6663 20.8332 41.6663C9.32733 41.6663 0 32.339 0 20.8332C0 9.32733 9.32733 0 20.8332 0C32.339 0 41.6663 9.32733 41.6663 20.8332ZM21.5797 15.38C19.5534 16.2228 15.5036 17.9672 9.43029 20.6132C8.44409 21.0054 7.92747 21.3891 7.88044 21.7642C7.80096 22.3983 8.59492 22.6479 9.67609 22.9879C9.82315 23.0341 9.97554 23.082 10.1318 23.1328C11.1955 23.4786 12.6263 23.8831 13.3702 23.8992C14.0449 23.9137 14.798 23.6356 15.6295 23.0646C21.3039 19.2342 24.2331 17.2981 24.417 17.2564C24.5468 17.227 24.7265 17.1899 24.8484 17.2982C24.9702 17.4065 24.9582 17.6115 24.9453 17.6665C24.8666 18.0018 21.75 20.8993 20.1372 22.3987C19.6344 22.8662 19.2778 23.1978 19.2048 23.2735C19.0415 23.4431 18.8751 23.6036 18.7151 23.7578C17.7269 24.7104 16.9858 25.4248 18.7561 26.5914C19.6069 27.1521 20.2876 27.6157 20.9668 28.0782C21.7085 28.5833 22.4482 29.087 23.4054 29.7145C23.6493 29.8743 23.8822 30.0403 24.109 30.2021C24.9722 30.8174 25.7476 31.3703 26.7057 31.2821C27.2624 31.2309 27.8374 30.7074 28.1294 29.1462C28.8196 25.4566 30.1762 17.4625 30.4897 14.1682C30.5172 13.8796 30.4826 13.5103 30.4549 13.3481C30.4271 13.186 30.3691 12.9549 30.1584 12.7839C29.9088 12.5814 29.5234 12.5387 29.3511 12.5417C28.5675 12.5555 27.3653 12.9735 21.5797 15.38Z" fill="#008EE9" />
                          </g>
                          <defs>
                            <clipPath id="clip0_4021_422">
                              <rect width="41.6663" height="41.6663" fill="white" />
                            </clipPath>
                          </defs>
                        </svg>
                    </a>
                </div>
            </div>
            <div class="footer__bottom-links">
                <a href="">Политика конфиденциальности</a>
                <a href="">Карта сайта</a>
                <a href="">Политика Cookie</a>
                <a href="">Публичная оферта</a>
            </div>
        </div>
    </div>
</footer>

<div id="lead-modal" class="modal">
    <div class="modal-content">
        <span class="close"></span>

        <div class="modal-title">
            Забронировать время
        </div>
        <div class="modal-sub">
            Оставте свои контакты и мы свяжемся с вами
            <br> и подберем удобное для вас время.
        </div>
    
        <form action="/lead.php" method="POST" class="form">
            <div class="form-group">
                <input type="text" name="name" placeholder="*Имя">
            </div>
            <div class="form-group">
                <input type="text" name="tel" required="" placeholder="*Телефон">
            </div>
            <div class="form-group form-group__terms">
                <label for="term-2">
                    <input type="checkbox" id="term-2">
                    <div>
                         Я выражаю Согласие на передачу и обработку персональных данных, в соответствии с Политикой конфиденциальности
                     </div>
                </label>
            </div>

            <div class="form__submit">
                <button type="submit" class="btn">Забронировать</button>
            </div>

        </form>

    </div>
</div>

<style>
/* Звездочки */
.stars-container {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-bottom: 30px;
}

.star {
    font-size: 48px;
    cursor: pointer;
    color: #ddd;
    transition: all 0.2s;
    user-select: none;
}

.star.active {
    color: #ffc107;
}

.star:hover {
    transform: scale(1.1);
}
.robot-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 20px;
    display: block;
}

/* Кнопки агрегаторов */
.aggregator-buttons {
    display: flex;
    gap: 12px;
    justify-content: center;
    flex-wrap: wrap;
}

.aggregator-btn {
    padding: 12px 24px;
    border-radius: 12px;
    border: none;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.aggregator-btn.yandex {
    background: #f0f0f0;
    color: #999;
}

.aggregator-btn.2gis {
    background: #00a8e8;
    color: white;
}

.aggregator-btn.google {
    background: #f0f0f0;
    color: #999;
}

.aggregator-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}
</style>

<div id="rating-modal" class="modal">
    <div class="modal-content">
        <span class="close" data-modal="rating-modal"></span>
        
        <div class="modal-title">
            Оцените<br>нашу работу
        </div>

        <div class="stars-container">
            <span class="star" data-rating="1">★</span>
            <span class="star" data-rating="2">★</span>
            <span class="star" data-rating="3">★</span>
            <span class="star" data-rating="4">★</span>
            <span class="star" data-rating="5">★</span>
        </div>

        <button type="button" class="btn" id="submit-rating" disabled>Отправить</button>
    </div>
</div>

<!-- Модальное окно 2: Положительная оценка - отзывы на агрегаторах -->
<div id="review-aggregator-modal" class="modal">
    <div class="modal-content">
        <span class="close" data-modal="review-aggregator-modal"></span>
        
        <div class="modal-title">
            Спасибо<br>за оценку<br>нашей работы
        </div>

        <div class="review-aggregator__icon">
            <img src="/img/problems/bot3.png" alt="">
        </div>

        <div class="modal-sub">
            Оставьте отзыв на карте
        </div>

        <div class="aggregator-buttons">
            <a href="YOUR_YANDEX_MAPS_LINK" target="_blank" class="aggregator-btn yandex">Яндекс</a>
            <a href="YOUR_2GIS_LINK" target="_blank" class="aggregator-btn 2gis">2GIS</a>
            <a href="YOUR_GOOGLE_MAPS_LINK" target="_blank" class="aggregator-btn google">Google</a>
        </div>
    </div>
</div>

<!-- Модальное окно 3: Отрицательная оценка - форма обратной связи -->
<div id="feedback-modal" class="modal">
    <div class="modal-content">
        <span class="close" data-modal="feedback-modal"></span>
        
        <div class="modal-title">
            Расскажите, что не так
        </div>

        <div class="modal-sub">
            Мы хотим стать лучше, поэтому передадим<br>ваш отзыв в нашу службу заботы о клиенте
        </div>

        <form action="/lead.php" method="POST" class="form">
            <div class="form-group">
                <input type="text" name="name" placeholder="*Имя" required>
            </div>
            <div class="form-group">
                <input type="text" name="tel" placeholder="*Телефон" required>
            </div>
            <div class="form-group">
                <textarea name="feedback" placeholder="Ваш отзыв" required></textarea>
            </div>
            <div class="form-group form-group__terms">
                <label for="term-feedback">
                    <input type="checkbox" id="term-feedback" name="terms" required>
                    <div>
                        Я выражаю Согласие на передачу и обработку персональных данных, в соответствии с Политикой конфиденциальности
                    </div>
                </label>
            </div>

            <div class="form__submit">
                <button type="submit" class="btn">Отправить</button>
            </div>
        </form>
    </div>
</div>

<script>
    jQuery(document).ready(function($) {
        let selectedRating = 0;

        // Обработка выбора звезд
        $('.star').on('click', function() {
            selectedRating = parseInt($(this).data('rating'));
            updateStars(selectedRating);
            $('#submit-rating').prop('disabled', false);
        });

        $('.star').on('mouseenter', function() {
            const rating = parseInt($(this).data('rating'));
            updateStars(rating);
        });

        $('.stars-container').on('mouseleave', function() {
            updateStars(selectedRating);
        });

        function updateStars(rating) {
            $('.star').each(function(index) {
                if (index < rating) {
                    $(this).addClass('active');
                } else {
                    $(this).removeClass('active');
                }
            });
        }

        // Отправка оценки
        $('#submit-rating').on('click', function() {
            if (selectedRating === 0) return;

            $('#rating-modal').hide();

            // Сохраняем оценку для отправки с формой
            $('#rating-value').val(selectedRating);

            // Если оценка больше 3 - показываем форму с агрегаторами
            if (selectedRating > 3) {
                setTimeout(function() {
                    $('#review-aggregator-modal').css('display', 'flex');
                }, 300);
            } else {
                // Если оценка 3 и меньше - показываем форму обратной связи
                setTimeout(function() {
                    $('#feedback-modal').css('display', 'flex');
                }, 300);
            }

            // Опционально: отправка оценки на сервер
            sendRatingToServer(selectedRating);
        });

        // Обработка отправки формы обратной связи
        $('#feedback-form').on('submit', function(e) {
            e.preventDefault();
            
            var formData = $(this).serialize();
            
            // Отправка данных на сервер через AJAX
            $.ajax({
                url: '/lead.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    alert('Спасибо за ваш отзыв! Мы обязательно учтём ваши пожелания.');
                    $('#feedback-modal').hide();
                    $('#feedback-form')[0].reset();
                    resetRatingModal();
                },
                error: function() {
                    alert('Произошла ошибка при отправке. Попробуйте позже.');
                }
            });
        });

        // Функция отправки оценки на сервер (опционально)
        function sendRatingToServer(rating) {
            $.ajax({
                url: '/rating.php',
                type: 'POST',
                data: { rating: rating },
                dataType: 'json',
                success: function(data) {
                    console.log('Оценка отправлена:', data);
                },
                error: function(error) {
                    console.error('Ошибка отправки оценки:', error);
                }
            });
        }

        // Сброс состояния модального окна с оценкой
        function resetRatingModal() {
            selectedRating = 0;
            updateStars(0);
            $('#submit-rating').prop('disabled', true);
        }
    });
</script>

<div id="success-modal" class="modal">
    <div class="modal-content">
        <span class="close"></span>

        <div class="modal-title">
            Спасибо за заявку
        </div>
        <div class="modal-text">
            <p>
                Менеджер с Вами свяжется
            </p>
        </div>

    </div>
</div>

<?php wp_footer(); ?>
 
</body>
</html>