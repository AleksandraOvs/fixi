<?php 
/* Template Name: Главная */
get_header();

$faq = get_field('faq') ?: [];
?>

<div class="main">
    <div class="hero">
        <div class="container">
            <div class="hero__in">
                <div class="hero__title">
                    <span>Fixibot</span>
                    <br> ваш надежный
                    <br> ремонт техники
                    <br> в Омске!
                </div>

                <div class="hero__features">
                    <div class="hero__feature hero__feature-top">
                        <svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_437_22919)">
                        <path d="M24 6.32912C23.7222 6.61095 23.4672 6.87265 23.2082 7.13167C22.0084 8.33012 20.8046 9.5259 19.6061 10.727C18.8666 11.4679 18.0064 12.0168 17.0119 12.3295C16.3516 12.5361 15.6685 12.6435 14.968 12.6395C12.9898 12.6301 11.0116 12.6301 9.03338 12.6395C8.35564 12.6422 7.69401 12.5455 7.05251 12.3536C6.18822 12.0959 5.39775 11.6786 4.73612 11.0585C4.12414 10.4868 3.53498 9.89094 2.94045 9.30043C2.04664 8.41199 1.15685 7.51684 0.265727 6.62571C0.179836 6.53982 0.0966281 6.45125 0 6.35059C0.0496561 6.27678 0.0818655 6.20565 0.132864 6.15465C1.65073 4.64215 3.16323 3.12294 4.69586 1.62521C5.27697 1.05752 5.98289 0.673691 6.75189 0.403938C7.57323 0.115396 8.4147 -0.00136341 9.28032 0.0013207C11.2142 0.00803098 13.1468 -0.00941575 15.0807 0.00803098C15.7719 0.0147413 16.4456 0.154315 17.1112 0.36636C18.2681 0.734084 19.1646 1.46014 19.9966 2.30429C21.2421 3.56851 22.5036 4.81796 23.7571 6.07413C23.8336 6.15062 23.9074 6.23115 24 6.32912ZM12.0678 10.7834C12.9723 10.7834 13.8782 10.7861 14.7828 10.7834C15.749 10.7807 16.6657 10.5995 17.4924 10.0627C18.5835 9.35546 19.2397 8.34623 19.4773 7.08872C19.6893 5.96139 19.4558 4.89178 18.8223 3.92549C17.9715 2.62773 16.7529 1.92449 15.2136 1.89228C13.0582 1.84665 10.9015 1.87081 8.74484 1.89094C8.3382 1.89496 7.92082 1.97951 7.52894 2.09761C6.66063 2.35797 5.94934 2.87198 5.38836 3.58327C4.91059 4.18988 4.59118 4.87701 4.49186 5.64333C4.39524 6.39085 4.43147 7.13167 4.71062 7.85235C5.07297 8.79045 5.66482 9.52858 6.50629 10.0761C7.31287 10.6009 8.2107 10.7767 9.15283 10.7834C10.1245 10.7901 11.0961 10.7847 12.0691 10.7847L12.0678 10.7834Z" fill="white"/>
                        <path d="M13.034 6.3578C12.9723 5.28147 13.956 4.28835 15.031 4.2709C16.1878 4.25077 17.1608 5.15263 17.1675 6.29472C17.1743 7.39923 16.3932 8.37625 15.0954 8.38833C13.8849 8.40041 13.0313 7.41668 13.034 6.3578Z" fill="white"/>
                        <path d="M8.88882 4.28145C10.0068 4.22106 10.961 5.237 10.9462 6.3348C10.9314 7.40576 10.1168 8.37607 8.90224 8.38815C7.61386 8.40023 6.81534 7.36953 6.80863 6.31467C6.80192 5.23566 7.75746 4.21435 8.88882 4.28145Z" fill="white"/>
                        </g>
                        <defs>
                        <clipPath id="clip0_437_22919">
                        <rect width="24" height="12.6396" fill="white"/>
                        </clipPath>
                        </defs>
                        </svg>
                        Срочный ремонт от 30 минут
                    </div>
                    <div class="hero__feature hero__feature-bottom">
                        <svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_437_22919)">
                        <path d="M24 6.32912C23.7222 6.61095 23.4672 6.87265 23.2082 7.13167C22.0084 8.33012 20.8046 9.5259 19.6061 10.727C18.8666 11.4679 18.0064 12.0168 17.0119 12.3295C16.3516 12.5361 15.6685 12.6435 14.968 12.6395C12.9898 12.6301 11.0116 12.6301 9.03338 12.6395C8.35564 12.6422 7.69401 12.5455 7.05251 12.3536C6.18822 12.0959 5.39775 11.6786 4.73612 11.0585C4.12414 10.4868 3.53498 9.89094 2.94045 9.30043C2.04664 8.41199 1.15685 7.51684 0.265727 6.62571C0.179836 6.53982 0.0966281 6.45125 0 6.35059C0.0496561 6.27678 0.0818655 6.20565 0.132864 6.15465C1.65073 4.64215 3.16323 3.12294 4.69586 1.62521C5.27697 1.05752 5.98289 0.673691 6.75189 0.403938C7.57323 0.115396 8.4147 -0.00136341 9.28032 0.0013207C11.2142 0.00803098 13.1468 -0.00941575 15.0807 0.00803098C15.7719 0.0147413 16.4456 0.154315 17.1112 0.36636C18.2681 0.734084 19.1646 1.46014 19.9966 2.30429C21.2421 3.56851 22.5036 4.81796 23.7571 6.07413C23.8336 6.15062 23.9074 6.23115 24 6.32912ZM12.0678 10.7834C12.9723 10.7834 13.8782 10.7861 14.7828 10.7834C15.749 10.7807 16.6657 10.5995 17.4924 10.0627C18.5835 9.35546 19.2397 8.34623 19.4773 7.08872C19.6893 5.96139 19.4558 4.89178 18.8223 3.92549C17.9715 2.62773 16.7529 1.92449 15.2136 1.89228C13.0582 1.84665 10.9015 1.87081 8.74484 1.89094C8.3382 1.89496 7.92082 1.97951 7.52894 2.09761C6.66063 2.35797 5.94934 2.87198 5.38836 3.58327C4.91059 4.18988 4.59118 4.87701 4.49186 5.64333C4.39524 6.39085 4.43147 7.13167 4.71062 7.85235C5.07297 8.79045 5.66482 9.52858 6.50629 10.0761C7.31287 10.6009 8.2107 10.7767 9.15283 10.7834C10.1245 10.7901 11.0961 10.7847 12.0691 10.7847L12.0678 10.7834Z" fill="white"/>
                        <path d="M13.034 6.3578C12.9723 5.28147 13.956 4.28835 15.031 4.2709C16.1878 4.25077 17.1608 5.15263 17.1675 6.29472C17.1743 7.39923 16.3932 8.37625 15.0954 8.38833C13.8849 8.40041 13.0313 7.41668 13.034 6.3578Z" fill="white"/>
                        <path d="M8.88882 4.28145C10.0068 4.22106 10.961 5.237 10.9462 6.3348C10.9314 7.40576 10.1168 8.37607 8.90224 8.38815C7.61386 8.40023 6.81534 7.36953 6.80863 6.31467C6.80192 5.23566 7.75746 4.21435 8.88882 4.28145Z" fill="white"/>
                        </g>
                        <defs>
                        <clipPath id="clip0_437_22919">
                        <rect width="24" height="12.6396" fill="white"/>
                        </clipPath>
                        </defs>
                        </svg>
                        Бесплатная диагностика за 15 минут 
                    </div>
                </div>

                <div class="hero__img">
                    <img src="/img/bot.png" alt="">
                </div>
            </div>
        </div>
    </div>

    <?php get_template_part('parts/search-box'); ?>

    <div class="features p-100">

        <div class="features__circle"></div>

        <div class="features__list">
            <div class="container">
                <h2 class="h2_center">
                    Почему
                    <br>жители Омска доверяют Fixibot?
                    <br><span>Наши преимущества</span>
                </h2>

                <?php if (wp_is_mobile()) : ?>

                    <div class="features__row row m-2">
                        
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/1.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Опыт
                                    </div>
                                    <div class="feature-item__sub">
                                        Мастера с опытом от 5 лет.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/2.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Удобство
                                    </div>
                                    <div class="feature-item__sub">
                                        Работаем 
                                        ежедневно с 10:00 до 20:00.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/3.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Скорость
                                    </div>
                                    <div class="feature-item__sub">
                                        80% ремонтов — в день обращения.
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/4.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Качество
                                    </div>
                                    <div class="feature-item__sub">
                                        Оригинальные 
                                        или сертифицированные запчасти.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/5.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Гарантия
                                    </div>
                                    <div class="feature-item__sub">
                                        До 12 месяцев на работы и запчасти.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/6.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Прозрачность
                                    </div>
                                    <div class="feature-item__sub">
                                        Стоимость фиксируется до ремонта.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon feature-item__icon-last">
                                    <img src="/img/features/7.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Прозрачность
                                    </div>
                                    <div class="feature-item__sub">
                                        Стоимость фиксируется до ремонта.
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                <?php else : ?>

                    <div class="features__row row m-2">
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/1.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Опыт
                                    </div>
                                    <div class="feature-item__sub">
                                        Мастера с опытом от 5 лет.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/2.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Удобство
                                    </div>
                                    <div class="feature-item__sub">
                                        Работаем 
                                        ежедневно с 10:00 до 20:00.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/3.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Скорость
                                    </div>
                                    <div class="feature-item__sub">
                                        80% ремонтов — в день обращения.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="features__row m-2 row">
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/4.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Качество
                                    </div>
                                    <div class="feature-item__sub">
                                        Оригинальные 
                                        или сертифицированные запчасти.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/5.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Гарантия
                                    </div>
                                    <div class="feature-item__sub">
                                        До 12 месяцев на работы и запчасти.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon">
                                    <img src="/img/features/6.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Прозрачность
                                    </div>
                                    <div class="feature-item__sub">
                                        Стоимость фиксируется до ремонта.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="feature-item">
                                <div class="feature-item__icon feature-item__icon-last">
                                    <img src="/img/features/7.png" alt="">
                                </div>
                                <div class="feature-item__content">
                                    <div class="feature-item__title">
                                        Прозрачность
                                    </div>
                                    <div class="feature-item__sub">
                                        Стоимость фиксируется до ремонта.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endif ?>

            </div>
        </div>

    </div>

    <div class="front-wrapper">
        <div class="about" id="about">
            <div class="container">
                <div class="row auto-h">
                    <div class="col-6">
                        <div class="about__item">
                            <h2>
                                о нас
                                <br> <span>кто такие Fixibot?</span>
                            </h2>
                            <div class="about__text">
                                Мы работаем в сфере ремонта техники в Омске уже более 16 лет и зарекомендовали себя как надежный сервисный центр. 
        В нашей команде работают только квалифицированные инженеры с многолетним опытом, что обеспечивает высокий уровень обслуживания. В 95% случаев профессиональный ремонт оказывается выгоднее покупки новой техники, и мы это подтверждаем на деле. Быстрая диагностика и использование только оригинальных запчастей позволяют нам выполнять большинство работ за 1-2 дня. Обратившись к нам, вы получите качественный ремонт, которым можно доверять.
                            </div>
                            <div class="about__sub">
                                Не откладывайте ремонт! 
        Звоните прямо сейчас!
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="about__item about__item-blue">
                            <h2 class="about-item__title">
                                Наша миссия — 
                            </h2>
                            <div class="about-item__sub">
                                продлевать жизнь вашим устройствам, помогая вам экономить время и деньги
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="reviews" id="reviews">
            
            <div class="container">
        
                <div class="reviews__in">
                    <div class="reviews__header">
                        <div class="reviews__header-in">
                            <h2>
                                Что говорят 
                                <br>наши
                                <br>клиенты
                                <br><span>Отзывы</span>
                            </h2>
                            
                            <div class="reviews__count-title">
                                <div class="reviews__rait-title">
                                    Отзывы с Яндекс карт:
                                </div>
                                <div class="reviews__rait-count">
                                    <div class="reviews__stars fs">
                                        <img src="/img/stars.svg" alt="">
                                    </div>
                                    <div class="reviews__count">
                                        4.9
                                    </div>
                                </div>
                            </div>
                            <div class="reviews__add-review">
                                <a href="#" class="btn" data-toggle="modal" data-target="#rating-modal">Оценить работу</a>
                            </div>
                        </div>
                    </div>
                    <div class="reviews-slider swiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="review-item">
                                    <div class="review-item__header">
                                        <div class="review-item__name">
                                            Анна
                                            <br>34 года
                                        </div>
                                        <div class="review-item__logo">
                                            <img src="/img/logos/ya.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="review-item__quote-top">
                                        <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_437_23355)">
                                        <path d="M17.8439 2.65757C15.6072 3.7071 9.32545 7.54546 7.78917 14.7364H14.8804C16.3289 14.7364 17.5031 15.8947 17.5031 17.3237V29.4124C17.5031 30.8415 16.3289 31.9998 14.8804 31.9998H2.62271C1.17414 31.9998 0 30.8415 0 29.4124V21.4934H0.00125308C0.174179 6.78768 12.5872 1.456 16.7926 0.0714629C17.5394 -0.174539 18.3452 0.230931 18.5795 0.972645L18.5857 0.991188C18.795 1.65131 18.4767 2.36089 17.8439 2.65757Z" fill="#EDF6FF"/>
                                        <path d="M44.3947 2.65757C42.1579 3.7071 35.8762 7.54546 34.34 14.7364H41.4312C42.8797 14.7364 44.0539 15.8947 44.0539 17.3237V29.4124C44.0539 30.8415 42.8797 31.9998 41.4312 31.9998H29.1735C27.7249 31.9998 26.5508 30.8415 26.5508 29.4124V21.4934H26.552C26.725 6.78768 39.138 1.456 43.3434 0.0714629C44.0902 -0.174539 44.8959 0.230931 45.1303 0.972645L45.1365 0.991188C45.3458 1.65131 45.0275 2.36089 44.3947 2.65757Z" fill="#EDF6FF"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_437_23355">
                                        <rect width="45.2" height="32" fill="white"/>
                                        </clipPath>
                                        </defs>
                                        </svg>
                                    </div>
                                    <div class="review-item__text">
                                        Разбила экран iPhone 12. 
        В Fixibot заменили за 2 часа, 
        экран как оригинальный!
                                    </div>
                                    <div class="review-item__date-quote">
                                        <div class="review-item__date">
                                            Дата 16.05.2025
                                        </div>
                                        <div class="review-item__quote">
                                            <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_437_23362)">
                                            <path d="M27.3561 29.3424C29.5928 28.2929 35.8745 24.4545 37.4108 17.2636H30.3196C28.8711 17.2636 27.6969 16.1053 27.6969 14.6763V2.58758C27.6969 1.15855 28.8711 0.000236511 30.3196 0.000236511H42.5773C44.0259 0.000236511 45.2 1.15855 45.2 2.58758V10.5066H45.1987C45.0258 25.2123 32.6128 30.544 28.4074 31.9285C27.6606 32.1745 26.8548 31.7691 26.6205 31.0274L26.6143 31.0088C26.405 30.3487 26.7233 29.6391 27.3561 29.3424Z" fill="#EDF6FF"/>
                                            <path d="M0.8053 29.3424C3.04206 28.2929 9.32377 24.4545 10.86 17.2636H3.76884C2.32028 17.2636 1.14614 16.1053 1.14614 14.6763V2.58758C1.14614 1.15855 2.32028 0.000236511 3.76884 0.000236511H16.0265C17.4751 0.000236511 18.6492 1.15855 18.6492 2.58758V10.5066H18.648C18.475 25.2123 6.06199 30.544 1.85664 31.9285C1.1098 32.1745 0.304068 31.7691 0.0697403 31.0274L0.0634727 31.0088C-0.145792 30.3487 0.172493 29.6391 0.8053 29.3424Z" fill="#EDF6FF"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_437_23362">
                                            <rect width="45.2" height="32" fill="white" transform="matrix(-1 0 0 -1 45.2 32)"/>
                                            </clipPath>
                                            </defs>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="review-item">
                                    <div class="review-item__header">
                                        <div class="review-item__name">
                                            Анна
                                            <br>34 года
                                        </div>
                                        <div class="review-item__logo fs">
                                            <img src="/img/logos/ya.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="review-item__stars">
                                        <img src="/img/stars.svg" alt="">
                                    </div>
                                    <div class="review-item__quote-top">
                                        <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_437_23355)">
                                        <path d="M17.8439 2.65757C15.6072 3.7071 9.32545 7.54546 7.78917 14.7364H14.8804C16.3289 14.7364 17.5031 15.8947 17.5031 17.3237V29.4124C17.5031 30.8415 16.3289 31.9998 14.8804 31.9998H2.62271C1.17414 31.9998 0 30.8415 0 29.4124V21.4934H0.00125308C0.174179 6.78768 12.5872 1.456 16.7926 0.0714629C17.5394 -0.174539 18.3452 0.230931 18.5795 0.972645L18.5857 0.991188C18.795 1.65131 18.4767 2.36089 17.8439 2.65757Z" fill="#EDF6FF"/>
                                        <path d="M44.3947 2.65757C42.1579 3.7071 35.8762 7.54546 34.34 14.7364H41.4312C42.8797 14.7364 44.0539 15.8947 44.0539 17.3237V29.4124C44.0539 30.8415 42.8797 31.9998 41.4312 31.9998H29.1735C27.7249 31.9998 26.5508 30.8415 26.5508 29.4124V21.4934H26.552C26.725 6.78768 39.138 1.456 43.3434 0.0714629C44.0902 -0.174539 44.8959 0.230931 45.1303 0.972645L45.1365 0.991188C45.3458 1.65131 45.0275 2.36089 44.3947 2.65757Z" fill="#EDF6FF"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_437_23355">
                                        <rect width="45.2" height="32" fill="white"/>
                                        </clipPath>
                                        </defs>
                                        </svg>
                                    </div>
                                    <div class="review-item__text">
                                        Разбила экран iPhone 12. 
        В Fixibot заменили за 2 часа, 
        экран как оригинальный!
                                    </div>
                                    <div class="review-item__date-quote">
                                        <div class="review-item__date">
                                            Дата 16.05.2025
                                        </div>
                                        <div class="review-item__quote fs">
                                            <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_437_23362)">
                                            <path d="M27.3561 29.3424C29.5928 28.2929 35.8745 24.4545 37.4108 17.2636H30.3196C28.8711 17.2636 27.6969 16.1053 27.6969 14.6763V2.58758C27.6969 1.15855 28.8711 0.000236511 30.3196 0.000236511H42.5773C44.0259 0.000236511 45.2 1.15855 45.2 2.58758V10.5066H45.1987C45.0258 25.2123 32.6128 30.544 28.4074 31.9285C27.6606 32.1745 26.8548 31.7691 26.6205 31.0274L26.6143 31.0088C26.405 30.3487 26.7233 29.6391 27.3561 29.3424Z" fill="#EDF6FF"/>
                                            <path d="M0.8053 29.3424C3.04206 28.2929 9.32377 24.4545 10.86 17.2636H3.76884C2.32028 17.2636 1.14614 16.1053 1.14614 14.6763V2.58758C1.14614 1.15855 2.32028 0.000236511 3.76884 0.000236511H16.0265C17.4751 0.000236511 18.6492 1.15855 18.6492 2.58758V10.5066H18.648C18.475 25.2123 6.06199 30.544 1.85664 31.9285C1.1098 32.1745 0.304068 31.7691 0.0697403 31.0274L0.0634727 31.0088C-0.145792 30.3487 0.172493 29.6391 0.8053 29.3424Z" fill="#EDF6FF"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_437_23362">
                                            <rect width="45.2" height="32" fill="white" transform="matrix(-1 0 0 -1 45.2 32)"/>
                                            </clipPath>
                                            </defs>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="review-item">
                                    <div class="review-item__header">
                                        <div class="review-item__name">
                                            Анна
                                            <br>34 года
                                        </div>
                                        <div class="review-item__logo">
                                            <img src="/img/logos/ya.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="review-item__quote-top">
                                        <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_437_23355)">
                                        <path d="M17.8439 2.65757C15.6072 3.7071 9.32545 7.54546 7.78917 14.7364H14.8804C16.3289 14.7364 17.5031 15.8947 17.5031 17.3237V29.4124C17.5031 30.8415 16.3289 31.9998 14.8804 31.9998H2.62271C1.17414 31.9998 0 30.8415 0 29.4124V21.4934H0.00125308C0.174179 6.78768 12.5872 1.456 16.7926 0.0714629C17.5394 -0.174539 18.3452 0.230931 18.5795 0.972645L18.5857 0.991188C18.795 1.65131 18.4767 2.36089 17.8439 2.65757Z" fill="#EDF6FF"/>
                                        <path d="M44.3947 2.65757C42.1579 3.7071 35.8762 7.54546 34.34 14.7364H41.4312C42.8797 14.7364 44.0539 15.8947 44.0539 17.3237V29.4124C44.0539 30.8415 42.8797 31.9998 41.4312 31.9998H29.1735C27.7249 31.9998 26.5508 30.8415 26.5508 29.4124V21.4934H26.552C26.725 6.78768 39.138 1.456 43.3434 0.0714629C44.0902 -0.174539 44.8959 0.230931 45.1303 0.972645L45.1365 0.991188C45.3458 1.65131 45.0275 2.36089 44.3947 2.65757Z" fill="#EDF6FF"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_437_23355">
                                        <rect width="45.2" height="32" fill="white"/>
                                        </clipPath>
                                        </defs>
                                        </svg>
                                    </div>
                                    <div class="review-item__text">
                                        Разбила экран iPhone 12. 
        В Fixibot заменили за 2 часа, 
        экран как оригинальный!
                                    </div>
                                    <div class="review-item__date-quote">
                                        <div class="review-item__date">
                                            Дата 16.05.2025
                                        </div>
                                        <div class="review-item__quote">
                                            <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_437_23362)">
                                            <path d="M27.3561 29.3424C29.5928 28.2929 35.8745 24.4545 37.4108 17.2636H30.3196C28.8711 17.2636 27.6969 16.1053 27.6969 14.6763V2.58758C27.6969 1.15855 28.8711 0.000236511 30.3196 0.000236511H42.5773C44.0259 0.000236511 45.2 1.15855 45.2 2.58758V10.5066H45.1987C45.0258 25.2123 32.6128 30.544 28.4074 31.9285C27.6606 32.1745 26.8548 31.7691 26.6205 31.0274L26.6143 31.0088C26.405 30.3487 26.7233 29.6391 27.3561 29.3424Z" fill="#EDF6FF"/>
                                            <path d="M0.8053 29.3424C3.04206 28.2929 9.32377 24.4545 10.86 17.2636H3.76884C2.32028 17.2636 1.14614 16.1053 1.14614 14.6763V2.58758C1.14614 1.15855 2.32028 0.000236511 3.76884 0.000236511H16.0265C17.4751 0.000236511 18.6492 1.15855 18.6492 2.58758V10.5066H18.648C18.475 25.2123 6.06199 30.544 1.85664 31.9285C1.1098 32.1745 0.304068 31.7691 0.0697403 31.0274L0.0634727 31.0088C-0.145792 30.3487 0.172493 29.6391 0.8053 29.3424Z" fill="#EDF6FF"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_437_23362">
                                            <rect width="45.2" height="32" fill="white" transform="matrix(-1 0 0 -1 45.2 32)"/>
                                            </clipPath>
                                            </defs>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        
        
            </div>
        </div>
        
        <div class="faq p-100">
            <div class="container">
                <h2>
                    Ответы на частые вопросы о ремонте в Fixibot
                    <br> <span>Вопрос/ответ</span>
                </h2>
                
                <div class="row">

                    <?php if (count($faq)) : ?>

                        <div class="col-8">
                            <div class="faq-list" itemscope itemtype="https://schema.org/FAQPage">

                                <?php foreach ($faq as $item) : ?>
                    
                                    <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                        <div class="faq-question">
                                            <div itemprop="name">
                                                <?= $item['question'] ?>
                                            </div>
                                            <div class="faq-item__btn">
                                                <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                  <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                                  <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                            <div class="faq-answer__in text-block" itemprop="text">
                                                <?= $item['answer'] ?>
                                            </div>
                                        </div>
                                    </div>

                                <?php endforeach ?>

                            </div>
                        </div>

                    <?php endif ?>

                   <div class="col-4">
                       <div class="faq-form">
                           <form action="" class="form">
                               <h2>
                                   не нашли ответ 
                                   <br>на свой вопрос?
                               </h2>
                               <div class="faq-form__sub">
                                   Напишите нам, мы вам поможем.
                               </div>
                
                               <div class="form-group">
                                   <input type="text" name="fio" placeholder="Имя">
                               </div>
                               <div class="form-group">
                                   <input type="text" name="tel" placeholder="*Телефон" required>
                               </div>
                               <div class="form-group">
                                   <textarea name="question" id="" placeholder="Ваш вопрос" rows="4" required></textarea>
                               </div>
                               <div class="form-group form-group__terms">
                                   <label for="term">
                                       <input type="checkbox" id="term">
                                       <div>
                                            Я выражаю Согласие на передачу и обработку персональных данных, в соответствии с Политикой конфиденциальности
                                        </div>
                                   </label>
                               </div>
                               <div class="form-group">
                                   <button type="submit" class="btn">Отправить</button>
                               </div>
                           </form>
                       </div>
                   </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    $team = get_posts([
        'post_type' => 'specs',
        'posts_per_page' => -1,
    ]);
    ?>

    <div class="team p-100">
        <div class="features__circle_2"></div>
        <div class="container">
            <h2>
                Наши специалисты —
                <br> профессионалы с опытом от 5 лет
            </h2>
            <div class="team__sub">
                Каждый мастер проходит обучение для работы с новейшей техникой.
            </div>

            <?php if (count($team)) : ?>
                <div class="team-list row">

                    <?php foreach ($team as $post) : setup_postdata($post); ?>
                        <div class="col-3">
                            <div class="team-item">
                                <div class="team-item__photo">
                                    <img src="<?= get_field('image')['sizes']['large'] ?>" alt="">
                                </div>
                                <div class="team-item__content">
                                    <div class="team-item__name">
                                        <?= $post->post_title ?>
                                    </div>
                                    <div class="team-item__text">
                                        <?= get_field('post') ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; wp_reset_postdata(); ?>

                </div>
            <?php endif ?>
        </div>
    </div>

    <?php
    /**
     * Блок выбора устройств и формы на главной странице
     * С реальными данными моделей и симптомов
     */

    // Получаем категории устройств
    $device_categories = get_posts(array(
        'post_type' => 'device',
        'posts_per_page' => -1,
        'orderby' => 'menu_order',
        'order' => 'ASC',
    ));

    // Собираем модели по категориям + симптомы
    $models_by_device = [];
    $symptoms_by_device = [];
    $all_models_data = [];

    foreach ($device_categories as $category) {
        $device_id = $category->ID;
        $device_slug = sanitize_title($category->post_title);
        
        // Получаем связанные модели через ACF Relationship
        $related_models = get_field('models', $device_id);
        
        if ($related_models && is_array($related_models)) {
            $models_by_device[$device_slug] = [];
            $symptoms_by_device[$device_slug] = [];
            
            foreach ($related_models as $model_post) {
                $model_id = $model_post->ID;
                $model_title = get_the_title($model_id);
                
                $model_data = [
                    'id' => $model_id,
                    'title' => $model_title,
                    'slug' => sanitize_title($model_title),
                    'url' => get_permalink($model_id)
                ];
                
                $models_by_device[$device_slug][] = $model_data;
                
                // Добавляем в общий массив
                if (!isset($all_models_data[$model_data['slug']])) {
                    $all_models_data[$model_data['slug']] = $model_data;
                }
                
                // Получаем симптомы из ACF repeater поля "prices"
                $prices = get_field('prices', $model_id);
                
                if ($prices && is_array($prices)) {
                    foreach ($prices as $price_item) {
                        if (isset($price_item['problem'])) {
                            $problem = sanitize_text_field($price_item['problem']);
                            
                            // Добавляем уникальные проблемы для этого типа устройства
                            if (!in_array($problem, $symptoms_by_device[$device_slug])) {
                                $symptoms_by_device[$device_slug][] = $problem;
                            }
                        }
                    }
                }
            }
            
            // Сортируем симптомы
            if (!empty($symptoms_by_device[$device_slug])) {
                sort($symptoms_by_device[$device_slug]);
            }
        }
    }

    // Первая категория по умолчанию
    $first_device_slug = array_key_first($models_by_device);
    ?>

    <div class="cta">
        <div class="container">
            <div class="cta__in">
                <h2>Узнать цену за 1 минуту</h2>
                <div class="cta__form">
                    <form class="cta-search" method="GET" action="<?php echo esc_url(home_url('/price-calculator/')); ?>">
                        
                        <!-- Вид устройства -->
                        <select class="search-form__input" id="cta-device-type" name="device_type" required>
                            <option value="" disabled selected>Вид устройства</option>
                            <?php foreach ($device_categories as $category): 
                                $device_slug = sanitize_title($category->post_title);
                            ?>
                                <option value="<?php echo esc_attr($device_slug); ?>">
                                    <?php echo esc_html($category->post_title); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <!-- Модель -->
                        <select class="search-form__input" id="cta-device-model" name="device_model" required>
                            <option value="" selected>Модель</option>
                            <?php 
                            // Выводим модели первой категории
                            if ($first_device_slug && isset($models_by_device[$first_device_slug])):
                                foreach ($models_by_device[$first_device_slug] as $model):
                            ?>
                                <option value="<?php echo esc_attr($model['slug']); ?>" data-device="<?php echo esc_attr($first_device_slug); ?>">
                                    <?php echo esc_html($model['title']); ?>
                                </option>
                            <?php 
                                endforeach;
                            endif;
                            ?>
                        </select>
                        
                        <!-- Что сломалось -->
                        <select class="search-form__input" id="cta-device-problem" name="device_problem" required>
                            <option value="" selected>Что сломалось</option>
                            <?php 
                            // Выводим симптомы первой категории
                            if ($first_device_slug && isset($symptoms_by_device[$first_device_slug])):
                                foreach ($symptoms_by_device[$first_device_slug] as $symptom):
                            ?>
                                <option value="<?php echo esc_attr(sanitize_title($symptom)); ?>" data-device="<?php echo esc_attr($first_device_slug); ?>">
                                    <?php echo esc_html($symptom); ?>
                                </option>
                            <?php 
                                endforeach;
                            endif;
                            ?>
                        </select>
                        
                        <button type="submit" class="btn btn--orange search-form__btn">
                            Узнать цену
                        </button>
                    </form>
                </div>
            </div>
            <div class="cta__bot">
                <img src="/img/bot2.png" alt="Fixibot">
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // 1. Получаем родительский контейнер, по которому будет двигаться мышь
        const ctaContainer = document.querySelector('.cta');
        // 2. Получаем элемент, который будет двигаться (бот)
        const botElement = document.querySelector('.cta__bot');

        if (ctaContainer && botElement) {
            // Слушаем движение мыши только внутри блока .cta
            ctaContainer.addEventListener('mousemove', function(e) {
                
                // e.offsetX / e.offsetY — это координаты мыши, 
                // отсчитанные от левого верхнего угла элемента .cta, 
                // независимо от прокрутки страницы.
                const relativeX = e.offsetX;
                const relativeY = e.offsetY;

                // Определяем центр блока .cta
                const ctaWidth = ctaContainer.offsetWidth;
                const ctaHeight = ctaContainer.offsetHeight;
                const ctaCenterX = ctaWidth / 2;
                const ctaCenterY = ctaHeight / 2;

                // Вычисляем смещение мыши относительно центра блока
                // (Центр блока теперь равен (0, 0) для нашего движения)
                const mouseX = relativeX - ctaCenterX;
                const mouseY = relativeY - ctaCenterY;

                // Определяем силу параллакса (чем больше число, тем меньше движение)
                const moveFactor = 20; 

                // Вычисляем величину сдвига для элемента бота
                const offsetX = mouseX / moveFactor;
                const offsetY = mouseY / moveFactor;
                
                // Применяем преобразование (инвертируем для эффекта "парения")
                botElement.style.transform = `translate3d(${-offsetX}px, ${-offsetY}px, 0)`; 
            });

            // Дополнительно: Сбрасываем позицию бота в центр (0,0), когда мышь покидает блок .cta
            ctaContainer.addEventListener('mouseleave', function() {
                botElement.style.transform = 'translate3d(0, 0, 0)';
            });
        }
    });
    </script>

    <?php get_template_part('parts/callback'); ?>

    <div class="video m-100">
        <div class="container">
            <div class="row auto-h">
                <div class="col-4">
                    <div class="video__blue">
                        Ремонт с Fixibot — это просто.
                        <br><span>Как мы работаем</span>
                    </div>
                </div>
                <div class="col-8">
                    <div class="video__in">
                        <img src="/img/video.jpg" alt="">
                        <button class="video__btn">
                            <svg width="63" height="63" viewBox="0 0 63 63" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_4005_1725)">
                            <path d="M60.5246 19.2387C58.9383 15.4877 56.667 12.1188 53.7741 9.22653C50.8819 6.33431 47.5129 4.06307 43.762 2.47604C39.8774 0.833028 35.7524 0 31.5003 0C27.2483 0 23.1233 0.833028 19.2387 2.47604C15.4877 4.06241 12.1188 6.33365 9.22653 9.22653C6.33431 12.1188 4.06307 15.4877 2.47604 19.2387C0.833028 23.1226 0 27.2483 0 31.5003C0 35.7524 0.833028 39.878 2.47604 43.762C4.06241 47.5129 6.33365 50.8819 9.22653 53.7741C12.1188 56.6664 15.4877 58.9376 19.2387 60.5246C23.1226 62.1676 27.2483 63.0007 31.5003 63.0007C35.7524 63.0007 39.8774 62.1676 43.762 60.5246C47.5129 58.9383 50.8819 56.667 53.7741 53.7741C56.6664 50.8819 58.9376 47.5129 60.5246 43.762C62.1676 39.878 63.0007 35.7524 63.0007 31.5003C63.0007 27.2483 62.1676 23.1233 60.5246 19.2387Z" fill="white"/>
                            </g>
                            <g clip-path="url(#clip1_4005_1725)">
                            <path d="M60.5246 19.2387C58.9382 15.4877 56.667 12.1188 53.7741 9.22653C50.8819 6.33431 47.5129 4.06307 43.762 2.47604C39.8774 0.833028 35.7524 0 31.5003 0C27.2483 0 23.1233 0.833028 19.2387 2.47604C15.4877 4.06241 12.1188 6.33365 9.22653 9.22653C6.33431 12.1188 4.06307 15.4877 2.47604 19.2387C0.833028 23.1226 0 27.2483 0 31.5003C0 35.7524 0.833028 39.878 2.47604 43.762C4.06241 47.5129 6.33365 50.8819 9.22653 53.7741C12.1188 56.6664 15.4877 58.9376 19.2387 60.5246C23.1226 62.1676 27.2483 63.0007 31.5003 63.0007C35.7524 63.0007 39.8774 62.1676 43.762 60.5246C47.5129 58.9382 50.8819 56.667 53.7741 53.7741C56.6664 50.8819 58.9376 47.5129 60.5246 43.762C62.1676 39.878 63.0007 35.7524 63.0007 31.5003C63.0007 27.2483 62.1676 23.1233 60.5246 19.2387ZM45.0132 34.2404L25.7323 48.1405C23.4986 49.7512 20.3799 48.155 20.3799 45.4004V17.5996C20.3799 14.8457 23.4986 13.2494 25.7323 14.8595L45.0132 28.7596C46.8827 30.1076 46.8827 32.8911 45.0132 34.2391V34.2404Z" fill="#11B8EC"/>
                            <path opacity="0.1" d="M59.7906 19.4643C58.2437 15.8075 56.0291 12.5235 53.2093 9.70306C50.3895 6.88327 47.1055 4.66933 43.4487 3.12246C39.6622 1.52094 35.64 0.708984 31.4946 0.708984C27.3492 0.708984 23.3276 1.52094 19.5405 3.12246C15.8837 4.66933 12.5997 6.88327 9.77989 9.70306C6.9601 12.5235 4.7455 15.8075 3.19863 19.4643C1.59711 23.2508 0.785156 27.273 0.785156 31.4184C0.785156 35.5638 1.57209 39.4603 3.12488 43.1948C7.56199 37.3807 13.6461 32.8823 20.3768 29.7596V17.5994C20.3768 14.8454 23.4956 13.2492 25.7293 14.8593L39.194 24.5665C46.5029 23.6413 53.9653 23.7091 61.3532 24.205C60.9641 22.5903 60.4425 21.0079 59.7892 19.4643H59.7906Z" fill="white"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_4005_1725">
                            <rect width="63.0007" height="63.0007" fill="white"/>
                            </clipPath>
                            <clipPath id="clip1_4005_1725">
                            <rect width="63.0007" height="63.0007" fill="white"/>
                            </clipPath>
                            </defs>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php get_template_part('parts/cta2'); ?>

    <div class="map" id="contacts">
        <div class="container">
            <h2>
                Расположение сервисного центра
                <br><span>Fixibot в Омске</span>
            </h2>

            <div class="map-container">
                <div class="map-info">
                    <div class="map-item">
                        <div class="map-item__title">
                            Адрес:
                        </div>
                        <div class="map-item__value">
                            ул. 6-я Станционная, 2 к 2
                            <br> ТК Пароплаза, 2-й этаж
                        </div>
                    </div>
                    <div class="map-item">
                        <div class="map-item__value">
                            Ежедневно с 10:00 до 20:00
                        </div>
                    </div>
                    <div class="map-item">
                        <div class="map-item__value">
                             +7 (495)47-81-80
                        </div>
                    </div>
                    <div class="map-item map-item_phone">
                        <div class="map-item__value">
                            <div class="map-item__social">
                                <a href="">
                                    <svg width="18" height="15" viewBox="0 0 18 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M1.10112 6.48381C1.10112 6.48381 9.0645 3.21217 11.8268 2.0617C12.8874 1.60032 16.4766 0.126285 16.4766 0.126285C16.4766 0.126285 18.1304 -0.520852 17.9926 1.04905C17.9447 1.69619 17.5791 3.94919 17.2076 6.38794C16.6564 9.83933 16.0572 13.6143 16.0572 13.6143C16.0572 13.6143 15.9673 14.6749 15.1823 14.8546C14.3974 15.0404 13.1091 14.2135 12.8814 14.0278C12.6957 13.8899 9.43001 11.8167 8.23161 10.804C7.90804 10.5284 7.54253 9.97715 8.27954 9.33001C9.93334 7.81403 11.9167 5.92655 13.1091 4.72815C13.6604 4.17688 14.2116 2.8886 11.9107 4.45252C8.64506 6.70551 5.42136 8.82668 5.42136 8.82668C5.42136 8.82668 4.68434 9.28807 3.30618 8.87462C1.92801 8.46117 0.316163 7.90991 0.316163 7.90991C0.316163 7.90991 -0.786366 7.22083 1.10112 6.48381Z" fill="#008EE9" />
                                    </svg>
                                </a>
                                <span>|</span>
                                <a href="">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M0 16L1.12467 11.8913C0.430667 10.6887 0.066 9.32533 0.0666667 7.92733C0.0686667 3.55667 3.62533 0 7.99533 0C10.116 0.000666667 12.1067 0.826667 13.604 2.32533C15.1007 3.824 15.9247 5.816 15.924 7.93467C15.922 12.306 12.3653 15.8627 7.99533 15.8627C6.66867 15.862 5.36133 15.5293 4.20333 14.8973L0 16ZM4.398 13.462C5.51533 14.1253 6.582 14.5227 7.99267 14.5233C11.6247 14.5233 14.5833 11.5673 14.5853 7.93333C14.5867 4.292 11.642 1.34 7.998 1.33867C4.36333 1.33867 1.40667 4.29467 1.40533 7.928C1.40467 9.41133 1.83933 10.522 2.56933 11.684L1.90333 14.116L4.398 13.462ZM11.9893 9.81933C11.94 9.73667 11.808 9.68733 11.6093 9.588C11.4113 9.48867 10.4373 9.00933 10.2553 8.94333C10.074 8.87733 9.942 8.844 9.80933 9.04267C9.67733 9.24067 9.29733 9.68733 9.182 9.81933C9.06667 9.95133 8.95067 9.968 8.75267 9.86867C8.55467 9.76933 7.916 9.56067 7.15933 8.88533C6.57067 8.36 6.17267 7.71133 6.05733 7.51267C5.942 7.31467 6.04533 7.20733 6.144 7.10867C6.23333 7.02 6.342 6.87733 6.44133 6.76133C6.542 6.64667 6.57467 6.564 6.64133 6.43133C6.70733 6.29933 6.67467 6.18333 6.62467 6.084C6.57467 5.98533 6.17867 5.01 6.014 4.61333C5.85267 4.22733 5.68933 4.27933 5.568 4.27333L5.188 4.26667C5.056 4.26667 4.84133 4.316 4.66 4.51467C4.47867 4.71333 3.96667 5.192 3.96667 6.16733C3.96667 7.14267 4.67667 8.08467 4.77533 8.21667C4.87467 8.34867 6.172 10.35 8.15933 11.208C8.632 11.412 9.00133 11.534 9.28867 11.6253C9.76333 11.776 10.1953 11.7547 10.5367 11.704C10.9173 11.6473 11.7087 11.2247 11.874 10.762C12.0393 10.2987 12.0393 9.902 11.9893 9.81933Z" fill="#008EE9" />
                                    </svg>
                                </a>
                            </div>

                            <a href="tel:+7 (908) 119-13-74">+7 (908) 119-13-74</a>
                        </div>
                    </div>

                    <div class="map__actions">
                        <button class="btn">
                            Закать выезд мастера
                        </button>
                        <button class="btn btn_ghost">
                            Закать доставку техники
                        </button>
                    </div>
                </div>
                <div class="map__frame">
                    <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A94ade426cbd00d8120e59cd2fc24125d575addf5848e8cf886c5723002e3ba14&amp;source=constructor&scroll=false" width="100%" height="600" frameborder="0"></iframe>
                </div>
            </div>
        </div>
    </div>

</div>


<?php get_footer(); ?>
