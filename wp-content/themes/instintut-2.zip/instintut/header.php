<!doctype html>
<html <?php language_attributes(); ?> class="no-js">

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <title><?php wp_title(''); ?></title>

    <link href="//www.google-analytics.com" rel="dns-prefetch">
    <link rel="shortcut icon" href="<?php echo esc_url( get_site_icon_url() ); ?>" />
    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo( 'name' ); ?>" href="<?php bloginfo( 'rss2_url' ); ?>" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/swiper.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/grid.css?v=4.2">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/main.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/mob.css?v=<?= time() ?>">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>

<?php

$logo = '/img/logo-dark.svg';
$header_class = 'dark';

if (is_front_page() || is_404()) {
    $logo = '/img/logo.svg';
    $header_class = '';
}
?>

<header class="<?= $header_class ?>">
    <div class="container">
        <div class="header__top">
            <div class="header__brand">
                <a href="/">
                    <img src="<?= $logo ?>" alt="">
                </a>
            </div>
            <ul class="header-top-nav">
                <li><a href="/#about">О нас</a></li>
                <li><a href="/#reviews">Отзывы</a></li>
                <li><a href="/#contacts">Контакты</a></li>
                <li class="header__search">
                    <a href="" class="js-search">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M7.07378 11.2472C9.32366 11.2472 11.1476 9.36575 11.1476 7.04489C11.1476 4.72402 9.32366 2.84259 7.07378 2.84259C4.82389 2.84259 3 4.72402 3 7.04489C3 9.36575 4.82389 11.2472 7.07378 11.2472Z" stroke="white" />
                          <path d="M10.0391 10.1012L13.0018 13.1574" stroke="white" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Поиск
                    </a>
                </li>
            </ul>
            <div class="header__social">
                <a href="<?= get_field('tg', 'option') ?>" target="_blank">
                    <svg class="fs" width="25" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.4845 8.71827C1.4845 8.71827 12.1826 4.32313 15.8935 2.77758C17.3183 2.15775 22.1401 0.177524 22.1401 0.177524C22.1401 0.177524 24.3618 -0.691846 24.1767 1.41718C24.1123 2.28655 23.6212 5.31324 23.1221 8.58948C22.3816 13.2261 21.5766 18.2974 21.5766 18.2974C21.5766 18.2974 21.4558 19.7222 20.4013 19.9637C19.3468 20.2133 17.6161 19.1024 17.3102 18.8529C17.0607 18.6677 12.6736 15.8825 11.0637 14.5221C10.629 14.1518 10.1379 13.4113 11.1281 12.5419C13.3498 10.5053 16.0142 7.96965 17.6161 6.35971C18.3567 5.61913 19.0973 3.88844 16.0062 5.98942C11.6191 9.01611 7.28834 11.8657 7.28834 11.8657C7.28834 11.8657 6.29823 12.4855 4.44679 11.9301C2.59536 11.3747 0.429984 10.6341 0.429984 10.6341C0.429984 10.6341 -1.05116 9.70839 1.4845 8.71827Z" fill="white"/>
                    </svg>
                </a>
                <a href="<?= get_field('wa', 'option') ?>" target="_blank">
                    <svg class="fs" width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 26L1.82758 19.3234C0.699833 17.3691 0.10725 15.1537 0.108333 12.8819C0.111583 5.77958 5.89117 0 12.9924 0C16.4385 0.00108333 19.6733 1.34333 22.1065 3.77867C24.5386 6.214 25.8776 9.451 25.8765 12.8938C25.8733 19.9973 20.0937 25.7768 12.9924 25.7768C10.8366 25.7758 8.71217 25.2352 6.83042 24.2082L0 26ZM7.14675 21.8758C8.96242 22.9537 10.6957 23.5993 12.9881 23.6004C18.8901 23.6004 23.6979 18.7969 23.7012 12.8917C23.7033 6.9745 18.9182 2.1775 12.9967 2.17533C7.09042 2.17533 2.28583 6.97883 2.28367 12.883C2.28258 15.2934 2.98892 17.0982 4.17517 18.9865L3.09292 22.9385L7.14675 21.8758ZM19.4827 15.9564C19.4025 15.8221 19.188 15.7419 18.8652 15.5805C18.5434 15.4191 16.9607 14.6402 16.6649 14.5329C16.3702 14.4257 16.1557 14.3715 15.9402 14.6943C15.7257 15.0161 15.1082 15.7419 14.9207 15.9564C14.7333 16.1709 14.5448 16.198 14.2231 16.0366C13.9013 15.8752 12.8635 15.5361 11.6339 14.4387C10.6773 13.585 10.0306 12.5309 9.84317 12.2081C9.65575 11.8863 9.82367 11.7119 9.984 11.5516C10.1292 11.4075 10.3057 11.1757 10.4672 10.9872C10.6307 10.8008 10.6838 10.6665 10.7922 10.4509C10.8994 10.2364 10.8463 10.0479 10.7651 9.8865C10.6838 9.72617 10.0403 8.14125 9.77275 7.49667C9.51058 6.86942 9.24517 6.95392 9.048 6.94417L8.4305 6.93333C8.216 6.93333 7.86717 7.0135 7.5725 7.33633C7.27783 7.65917 6.44583 8.437 6.44583 10.0219C6.44583 11.6068 7.59958 13.1376 7.75992 13.3521C7.92133 13.5666 10.0295 16.8188 13.2589 18.213C14.027 18.5445 14.6272 18.7428 15.0941 18.8912C15.8654 19.136 16.5674 19.1013 17.1221 19.019C17.7407 18.9269 19.0266 18.2401 19.2952 17.4883C19.5639 16.7353 19.5639 16.0907 19.4827 15.9564Z" fill="white"/>
                    </svg>
                </a>
            </div>
            <div class="header__phone">
                <a href="tel:<?= get_field('phone', 'option') ?>">
                    <svg class="fs" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 15.675C11.93 16.505 14.242 17 17 17V13L13 12L10 15.675ZM10 15.675C6.159 14.023 3.824 11.045 2.5 8M2.5 8C1.4 5.472 1 2.898 1 1H5L6 5L2.5 8Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    +7 (495) 134-40-91
                </a>
            </div>

            <button class="burger-menu js-show-menu">
                <span></span>
                <span></span>
            </button>

        </div>
        <div class="header__middle">

            <?php
            /**
             * Header Navigation from ACF
             * Вставить в header.php или в файл меню
             */

            $menu_items = get_field('menu_items', 'option');

            if ($menu_items): ?>
            <ul class="header__nav">
                <?php foreach ($menu_items as $index => $item): ?>
                    <?php
                    $has_dropdown = !empty($item['has_dropdown']);
                    $title = !empty($item['title']) ? $item['title'] : '';
                    $subtitle = $item['subtitle'] ?? '';
                    $url = $item['url'] ?? '#';
                    $dropdown_tabs = $item['dropdown_tabs'] ?? [];
                    
                    // Генерируем уникальный ID для dropdown
                    $dropdown_id = 'dropdown-' . $index;
                    ?>
                    
                    <li class="<?php echo $has_dropdown ? 'with-childs js-dropdown-parent' : ''; ?>">
                        <?php if ($has_dropdown): ?>
                            <a href="<?php echo esc_url($url); ?>" class="js-dropdown-toggle">
                                <?php if (!empty($title)): ?>
                                    <?php echo esc_html($title); ?> 
                                    <br>
                                <?php endif; ?>
                                <span><?php echo esc_html($subtitle); ?></span>
                            </a>
                            
                            <!-- Начало выпадающего меню -->
                            <div class="dropdown-menu" data-dropdown-id="<?php echo $dropdown_id; ?>">
                                <div class="dropdown-menu__inner">
                                    
                                    <?php if (!empty($dropdown_tabs)): ?>
                                        <!-- Верхняя часть: Табы -->
                                        <div class="dropdown-menu__tabs">
                                            <?php foreach ($dropdown_tabs as $tab_index => $tab): ?>
                                                <button 
                                                    class="dropdown-tab <?php echo $tab_index === 0 ? 'is-active' : ''; ?>" 
                                                    data-tab="<?php echo esc_attr($tab['tab_id']); ?>"
                                                    data-parent="<?php echo $dropdown_id; ?>"
                                                >
                                                    <?php echo esc_html($tab['tab_name']); ?>
                                                </button>
                                            <?php endforeach; ?>
                                        </div>

                                        <!-- Нижняя часть: Контент -->
                                        <div class="dropdown-menu__content">
                                            <?php foreach ($dropdown_tabs as $tab_index => $tab): ?>
                                                <div 
                                                    class="dropdown-content <?php echo $tab_index === 0 ? 'is-active' : ''; ?>" 
                                                    id="<?php echo esc_attr($tab['tab_id']); ?>"
                                                    data-parent="<?php echo $dropdown_id; ?>"
                                                >
                                                    <?php if (!empty($tab['tab_links'])): ?>
                                                        <ul class="brands-grid">
                                                            <?php foreach ($tab['tab_links'] as $link): ?>
                                                                <li>
                                                                    <a href="<?php echo esc_url($link['link_url']); ?>">
                                                                        <?php echo esc_html($link['link_text']); ?>
                                                                    </a>
                                                                </li>
                                                            <?php endforeach; ?>
                                                        </ul>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                            <!-- Конец выпадающего меню -->
                            
                        <?php else: ?>
                            <!-- Обычная ссылка без dropdown -->
                            <a href="<?php echo esc_url($url); ?>">
                                <?php if (!empty($title)): ?>
                                    <?php echo esc_html($title); ?> 
                                    <br>
                                <?php endif; ?>
                                <span><?php echo esc_html($subtitle); ?></span>
                            </a>
                        <?php endif; ?>
                    </li>
                    
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>

            <div class="header__city">
                <button>
                    <svg class="fs" width="12" height="16" viewBox="0 0 12 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M6.74062 15.6C8.34375 13.5938 12 8.73125 12 6C12 2.6875 9.3125 0 6 0C2.6875 0 0 2.6875 0 6C0 8.73125 3.65625 13.5938 5.25938 15.6C5.64375 16.0781 6.35625 16.0781 6.74062 15.6ZM6 4C6.53043 4 7.03914 4.21071 7.41421 4.58579C7.78929 4.96086 8 5.46957 8 6C8 6.53043 7.78929 7.03914 7.41421 7.41421C7.03914 7.78929 6.53043 8 6 8C5.46957 8 4.96086 7.78929 4.58579 7.41421C4.21071 7.03914 4 6.53043 4 6C4 5.46957 4.21071 4.96086 4.58579 4.58579C4.96086 4.21071 5.46957 4 6 4Z" fill="#FFBE42" />
                    </svg>
                    Омск
                </button>
            </div>

            <!-- Скрытая форма поиска -->
            <div class="search-panel js-search-panel">
                <div class="container search-panel__container">
                    <form action="/" method="get" class="search-panel__form">
                        <!-- Иконка поиска (кнопка сабмита) -->
                        <button type="submit" class="search-panel__submit">
                            <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.07378 11.2472C9.32366 11.2472 11.1476 9.36575 11.1476 7.04489C11.1476 4.72402 9.32366 2.84259 7.07378 2.84259C4.82389 2.84259 3 4.72402 3 7.04489C3 9.36575 4.82389 11.2472 7.07378 11.2472Z" stroke="currentColor" stroke-width="1.5"/>
                                <path d="M10.0391 10.1012L13.0018 13.1574" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        
                        <!-- Поле ввода -->
                        <input type="text" name="q" class="search-panel__input js-search-input" placeholder="Что вы ищете?" autocomplete="off">
                        
                        <!-- Кнопка закрыть -->
                        <button type="button" class="search-panel__close js-search-close">
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1L13 13M13 1L1 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</header>

<div class="panel-adaptive">
    <?php
    /**
     * Mobile Navigation Content
     * Только для вставки внутрь .panel-adaptive
     */

    $menu_items = get_field('menu_items', 'option');

    if ($menu_items): ?>
    <div class="mobile-nav">
        <ul class="mobile-nav__list">
            <?php foreach ($menu_items as $index => $item): ?>
                <?php
                $has_dropdown = !empty($item['has_dropdown']);
                $title = !empty($item['title']) ? $item['title'] : '';
                $subtitle = $item['subtitle'] ?? '';
                $url = $item['url'] ?? '#';
                $dropdown_tabs = $item['dropdown_tabs'] ?? [];
                $item_id = 'mobile-item-' . $index;
                ?>
                
                <li class="mobile-nav__item <?php echo $has_dropdown ? 'has-dropdown' : ''; ?>">
                    <?php if ($has_dropdown && !empty($dropdown_tabs)): ?>
                        <!-- Пункт с dropdown -->
                        <button 
                            class="mobile-nav__link mobile-nav__toggle" 
                            data-target="<?php echo $item_id; ?>"
                        >
                            <span class="mobile-nav__text">
                                <?php if (!empty($title)): ?>
                                    <?php echo esc_html($title); ?> 
                                <?php endif; ?>
                                <span><?php echo esc_html($subtitle); ?></span>
                            </span>
                            <svg class="mobile-nav__icon" width="20" height="20" viewBox="0 0 20 20">
                                <polyline points="6 8 10 12 14 8" fill="none" stroke="currentColor" stroke-width="2"/>
                            </svg>
                        </button>

                        <!-- Подменю -->
                        <div class="mobile-nav__dropdown" id="<?php echo $item_id; ?>">
                            <?php foreach ($dropdown_tabs as $tab_index => $tab): ?>
                                <?php $tab_id = $item_id . '-tab-' . $tab_index; ?>
                                
                                <div class="mobile-nav__tab">
                                    <!-- Заголовок таба -->
                                    <button 
                                        class="mobile-nav__tab-title" 
                                        data-target="<?php echo $tab_id; ?>"
                                    >
                                        <span><?php echo esc_html($tab['tab_name']); ?></span>
                                        <span class="mobile-nav__badge">
                                            <?php echo count($tab['tab_links']); ?>
                                        </span>
                                        <svg class="mobile-nav__icon" width="16" height="16" viewBox="0 0 20 20">
                                            <polyline points="6 8 10 12 14 8" fill="none" stroke="currentColor" stroke-width="2"/>
                                        </svg>
                                    </button>

                                    <!-- Контент таба -->
                                    <div class="mobile-nav__tab-content" id="<?php echo $tab_id; ?>">
                                        <?php if (!empty($tab['tab_links'])): ?>
                                            <ul class="mobile-nav__brands">
                                                <?php foreach ($tab['tab_links'] as $link): ?>
                                                    <li>
                                                        <a href="<?php echo esc_url($link['link_url']); ?>">
                                                            <?php echo esc_html($link['link_text']); ?>
                                                        </a>
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                            <?php endforeach; ?>
                        </div>

                    <?php else: ?>
                        <!-- Обычная ссылка -->
                        <a href="<?php echo esc_url($url); ?>" class="mobile-nav__link">
                            <span class="mobile-nav__text">
                                <?php if (!empty($title)): ?>
                                    <?php echo esc_html($title); ?> 
                                <?php endif; ?>
                                <span><?php echo esc_html($subtitle); ?></span>
                            </span>
                        </a>
                    <?php endif; ?>
                </li>
                
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // ========================================
    // 1. ОТКРЫТИЕ/ЗАКРЫТИЕ DROPDOWN МЕНЮ
    // ========================================
    
    const menuParents = document.querySelectorAll('.js-dropdown-parent');

    menuParents.forEach(parent => {
        const toggleBtn = parent.querySelector('.js-dropdown-toggle');
        
        if (!toggleBtn) return; // Защита от ошибок
        
        // Клик по кнопке открытия меню
        toggleBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const isOpen = parent.classList.contains('is-open');
            
            // Закрываем все другие открытые меню
            menuParents.forEach(item => {
                if (item !== parent) {
                    item.classList.remove('is-open');
                }
            });

            // Переключаем текущее меню
            if (isOpen) {
                parent.classList.remove('is-open');
            } else {
                parent.classList.add('is-open');
            }
        });
    });

    // Закрытие при клике вне меню
    document.addEventListener('click', function(e) {
        // Проверяем, был ли клик вне всех dropdown меню
        if (!e.target.closest('.js-dropdown-parent')) {
            menuParents.forEach(parent => {
                parent.classList.remove('is-open');
            });
        }
    });

    // Закрытие при нажатии ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            menuParents.forEach(parent => {
                parent.classList.remove('is-open');
            });
        }
    });


    // ========================================
    // 2. ПЕРЕКЛЮЧЕНИЕ ТАБОВ ВНУТРИ DROPDOWN
    // ========================================
    
    const tabs = document.querySelectorAll('.dropdown-tab');

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            // Получаем ID родительского dropdown
            const parentId = this.getAttribute('data-parent');
            const targetTabId = this.getAttribute('data-tab');
            
            // Находим родительский контейнер dropdown
            const menuContainer = this.closest('.dropdown-menu');
            
            if (!menuContainer) return;
            
            // Убираем активность у всех табов в ЭТОМ dropdown
            menuContainer.querySelectorAll('.dropdown-tab').forEach(t => {
                t.classList.remove('is-active');
            });
            
            // Убираем активность у всего контента в ЭТОМ dropdown
            menuContainer.querySelectorAll('.dropdown-content').forEach(c => {
                c.classList.remove('is-active');
            });

            // Активируем нажатый таб
            this.classList.add('is-active');
            
            // Активируем соответствующий контент
            const targetContent = menuContainer.querySelector(`#${targetTabId}[data-parent="${parentId}"]`);
            if (targetContent) {
                targetContent.classList.add('is-active');
            }
        });
    });

    
    // ========================================
    // 3. ЗАКРЫТИЕ ПРИ КЛИКЕ НА ССЫЛКУ ВНУТРИ
    // ========================================
    
    const dropdownLinks = document.querySelectorAll('.dropdown-content a');
    
    dropdownLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Закрываем все dropdown при переходе по ссылке
            menuParents.forEach(parent => {
                parent.classList.remove('is-open');
            });
        });
    });
    

    // ========================================
    // 4. АДАПТИВНОСТЬ (опционально)
    // ========================================
    
    // Если нужно закрывать меню при изменении размера экрана
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            menuParents.forEach(parent => {
                parent.classList.remove('is-open');
            });
        }, 250);
    });
});
</script>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const searchTrigger = document.querySelector('.js-search');
    const searchPanel = document.querySelector('.js-search-panel');
    const searchInput = document.querySelector('.js-search-input');
    const closeBtn = document.querySelector('.js-search-close');

    // Функция открытия
    const openSearch = (e) => {
        e.preventDefault();
        searchPanel.classList.add('is-active');
        // Небольшая задержка, чтобы анимация CSS успела отработать перед фокусом
        setTimeout(() => {
            searchInput.focus();
        }, 100);
    };

    // Функция закрытия
    const closeSearch = () => {
        searchPanel.classList.remove('is-active');
    };

    // События
    if (searchTrigger && searchPanel) {
        
        // 1. Клик по кнопке "Поиск" в шапке
        searchTrigger.addEventListener('click', openSearch);

        // 2. Клик по кнопке "Закрыть" (крестик)
        closeBtn.addEventListener('click', closeSearch);

        // 3. Закрытие при клике вне области формы (Body click)
        document.addEventListener('click', (e) => {
            const isClickInsideSearch = searchPanel.contains(e.target);
            const isClickOnTrigger = searchTrigger.contains(e.target);

            // Если клик не внутри панели И не по кнопке открытия — закрываем
            if (!isClickInsideSearch && !isClickOnTrigger && searchPanel.classList.contains('is-active')) {
                closeSearch();
            }
        });

        // 4. Закрытие по клавише Esc (UX best practice)
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && searchPanel.classList.contains('is-active')) {
                closeSearch();
            }
        });
    }
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // ========================================
    // АККОРДЕОН МОБИЛЬНОГО МЕНЮ
    // ========================================
    
    // Главные пункты с dropdown
    const mainToggles = document.querySelectorAll('.mobile-nav__toggle');
    
    mainToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('data-target');
            const dropdown = document.getElementById(targetId);
            
            if (!dropdown) return;
            
            const isOpen = dropdown.classList.contains('is-open');
            
            // Закрываем все другие dropdown на том же уровне
            document.querySelectorAll('.mobile-nav__dropdown.is-open').forEach(item => {
                if (item !== dropdown) {
                    item.classList.remove('is-open');
                    const otherToggle = document.querySelector(`[data-target="${item.id}"].mobile-nav__toggle`);
                    if (otherToggle) otherToggle.setAttribute('aria-expanded', 'false');
                }
            });
            
            // Переключаем текущий dropdown
            if (isOpen) {
                dropdown.classList.remove('is-open');
                this.setAttribute('aria-expanded', 'false');
            } else {
                dropdown.classList.add('is-open');
                this.setAttribute('aria-expanded', 'true');
            }
        });
    });
    
    // Табы внутри dropdown
    const tabToggles = document.querySelectorAll('.mobile-nav__tab-title');
    
    tabToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('data-target');
            const content = document.getElementById(targetId);
            
            if (!content) return;
            
            const isOpen = content.classList.contains('is-open');
            
            // Находим родительский dropdown
            const parentDropdown = this.closest('.mobile-nav__dropdown');
            
            // Закрываем другие табы в этом dropdown
            if (parentDropdown) {
                parentDropdown.querySelectorAll('.mobile-nav__tab-content.is-open').forEach(item => {
                    if (item !== content) {
                        item.classList.remove('is-open');
                        const otherToggle = document.querySelector(`[data-target="${item.id}"].mobile-nav__tab-title`);
                        if (otherToggle) otherToggle.setAttribute('aria-expanded', 'false');
                    }
                });
            }
            
            // Переключаем текущий таб
            if (isOpen) {
                content.classList.remove('is-open');
                this.setAttribute('aria-expanded', 'false');
            } else {
                content.classList.add('is-open');
                this.setAttribute('aria-expanded', 'true');
            }
        });
    });
    
    // Закрытие всех аккордеонов при клике на ссылку
    const brandLinks = document.querySelectorAll('.mobile-nav__brands a');
    
    brandLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Закрываем все dropdown (опционально)
            document.querySelectorAll('.mobile-nav__dropdown.is-open').forEach(dropdown => {
                dropdown.classList.remove('is-open');
            });
            
            document.querySelectorAll('.mobile-nav__tab-content.is-open').forEach(content => {
                content.classList.remove('is-open');
            });
        });
    });
});
</script>
