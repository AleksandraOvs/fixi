<!doctype html>
<html <?php language_attributes(); ?> class="no-js">

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <title><?php wp_title(''); ?></title>

    <link href="//www.google-analytics.com" rel="dns-prefetch">
    <link rel="shortcut icon" href="<?php echo esc_url( get_site_icon_url() ); ?>" />
    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo( 'name' ); ?>" href="<?php bloginfo( 'rss2_url' ); ?>" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/swiper.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/grid.css?v=4.2">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/main.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/mob.css?v=<?= time() ?>">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>

<?php

$logo = '/img/logo-dark.svg';
$header_class = 'dark';

if (is_front_page()) {
    $logo = '/img/logo.svg';
    $header_class = '';
}
?>

<header class="<?= $header_class ?>">
    <div class="container">
        <div class="header__top">
            <div class="header__brand">
                <a href="">
                    <img src="<?= $logo ?>" alt="">
                </a>
            </div>
            <ul class="header-top-nav">
                <li><a href="">О нас</a></li>
                <li><a href="">Отзывы</a></li>
                <li><a href="">Контакты</a></li>
                <li class="header__search">
                    <a href="" class="js-search">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M7.07378 11.2472C9.32366 11.2472 11.1476 9.36575 11.1476 7.04489C11.1476 4.72402 9.32366 2.84259 7.07378 2.84259C4.82389 2.84259 3 4.72402 3 7.04489C3 9.36575 4.82389 11.2472 7.07378 11.2472Z" stroke="white" />
                          <path d="M10.0391 10.1012L13.0018 13.1574" stroke="white" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Поиск
                    </a>
                </li>
            </ul>
            <div class="header__social">
                <a href="">
                    <svg class="fs" width="25" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.4845 8.71827C1.4845 8.71827 12.1826 4.32313 15.8935 2.77758C17.3183 2.15775 22.1401 0.177524 22.1401 0.177524C22.1401 0.177524 24.3618 -0.691846 24.1767 1.41718C24.1123 2.28655 23.6212 5.31324 23.1221 8.58948C22.3816 13.2261 21.5766 18.2974 21.5766 18.2974C21.5766 18.2974 21.4558 19.7222 20.4013 19.9637C19.3468 20.2133 17.6161 19.1024 17.3102 18.8529C17.0607 18.6677 12.6736 15.8825 11.0637 14.5221C10.629 14.1518 10.1379 13.4113 11.1281 12.5419C13.3498 10.5053 16.0142 7.96965 17.6161 6.35971C18.3567 5.61913 19.0973 3.88844 16.0062 5.98942C11.6191 9.01611 7.28834 11.8657 7.28834 11.8657C7.28834 11.8657 6.29823 12.4855 4.44679 11.9301C2.59536 11.3747 0.429984 10.6341 0.429984 10.6341C0.429984 10.6341 -1.05116 9.70839 1.4845 8.71827Z" fill="white"/>
                    </svg>
                </a>
                <a href="">
                    <svg class="fs" width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 26L1.82758 19.3234C0.699833 17.3691 0.10725 15.1537 0.108333 12.8819C0.111583 5.77958 5.89117 0 12.9924 0C16.4385 0.00108333 19.6733 1.34333 22.1065 3.77867C24.5386 6.214 25.8776 9.451 25.8765 12.8938C25.8733 19.9973 20.0937 25.7768 12.9924 25.7768C10.8366 25.7758 8.71217 25.2352 6.83042 24.2082L0 26ZM7.14675 21.8758C8.96242 22.9537 10.6957 23.5993 12.9881 23.6004C18.8901 23.6004 23.6979 18.7969 23.7012 12.8917C23.7033 6.9745 18.9182 2.1775 12.9967 2.17533C7.09042 2.17533 2.28583 6.97883 2.28367 12.883C2.28258 15.2934 2.98892 17.0982 4.17517 18.9865L3.09292 22.9385L7.14675 21.8758ZM19.4827 15.9564C19.4025 15.8221 19.188 15.7419 18.8652 15.5805C18.5434 15.4191 16.9607 14.6402 16.6649 14.5329C16.3702 14.4257 16.1557 14.3715 15.9402 14.6943C15.7257 15.0161 15.1082 15.7419 14.9207 15.9564C14.7333 16.1709 14.5448 16.198 14.2231 16.0366C13.9013 15.8752 12.8635 15.5361 11.6339 14.4387C10.6773 13.585 10.0306 12.5309 9.84317 12.2081C9.65575 11.8863 9.82367 11.7119 9.984 11.5516C10.1292 11.4075 10.3057 11.1757 10.4672 10.9872C10.6307 10.8008 10.6838 10.6665 10.7922 10.4509C10.8994 10.2364 10.8463 10.0479 10.7651 9.8865C10.6838 9.72617 10.0403 8.14125 9.77275 7.49667C9.51058 6.86942 9.24517 6.95392 9.048 6.94417L8.4305 6.93333C8.216 6.93333 7.86717 7.0135 7.5725 7.33633C7.27783 7.65917 6.44583 8.437 6.44583 10.0219C6.44583 11.6068 7.59958 13.1376 7.75992 13.3521C7.92133 13.5666 10.0295 16.8188 13.2589 18.213C14.027 18.5445 14.6272 18.7428 15.0941 18.8912C15.8654 19.136 16.5674 19.1013 17.1221 19.019C17.7407 18.9269 19.0266 18.2401 19.2952 17.4883C19.5639 16.7353 19.5639 16.0907 19.4827 15.9564Z" fill="white"/>
                    </svg>
                </a>
            </div>
            <div class="header__phone">
                <a href="">
                    <svg class="fs" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 15.675C11.93 16.505 14.242 17 17 17V13L13 12L10 15.675ZM10 15.675C6.159 14.023 3.824 11.045 2.5 8M2.5 8C1.4 5.472 1 2.898 1 1H5L6 5L2.5 8Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    +7 (495) 134-40-91
                </a>
            </div>

            <button class="burger-menu js-show-menu">
                <span></span>
                <span></span>
            </button>

        </div>
        <div class="header__middle">

            <ul class="header__nav">
                <li class="with-childs">
                    <a href="">
                        Ремонт 
                        <br><span>техники Apple</span>
                    </a>
                </li>
                <li class="with-childs">
                    <a href="">
                        Ремонт 
                        <br><span>телефонов</span>
                    </a>
                </li>
                <li class="with-childs js-dropdown-parent">
                    <a href="#" class="js-dropdown-toggle">
                        Ремонт <br><span>компьютерной техники</span>
                    </a>
                    
                    <!-- Начало выпадающего меню -->
                    <div class="dropdown-menu">
                        <div class="dropdown-menu__inner">
                            
                            <!-- Верхняя часть: Табы (Типы устройств) -->
                            <div class="dropdown-menu__tabs">
                                <button class="dropdown-tab is-active" data-tab="laptops">Ноутбуки</button>
                                <button class="dropdown-tab" data-tab="monoblocks">Моноблоки</button>
                                <button class="dropdown-tab" data-tab="pc">Системные блоки</button>
                            </div>

                            <!-- Нижняя часть: Контент (Бренды) -->
                            <div class="dropdown-menu__content">
                                
                                <!-- Контент для таба "Ноутбуки" -->
                                <div class="dropdown-content is-active" id="laptops">
                                    <ul class="brands-grid">
                                        <li><a href="#">Acer</a></li>
                                        <li><a href="#">Apple</a></li>
                                        <li><a href="#">Asus</a></li>
                                        <li><a href="#">Dell</a></li>
                                        <li><a href="#">HP</a></li>
                                        <li><a href="#">Lenovo</a></li>
                                        <li><a href="#">MSI</a></li>
                                        <li><a href="#">Samsung</a></li>
                                        <li><a href="#">Sony</a></li>
                                        <li><a href="#">Toshiba</a></li>
                                        <li><a href="#">Xiaomi</a></li>
                                        <li><a href="#">Huawei</a></li>
                                    </ul>
                                </div>

                                <!-- Контент для таба "Моноблоки" -->
                                <div class="dropdown-content" id="monoblocks">
                                    <ul class="brands-grid">
                                        <li><a href="#">Apple iMac</a></li>
                                        <li><a href="#">HP</a></li>
                                        <li><a href="#">Lenovo</a></li>
                                        <li><a href="#">Dell</a></li>
                                        <li><a href="#">MSI</a></li>
                                        <li><a href="#">Acer</a></li>
                                    </ul>
                                </div>

                                <!-- Контент для таба "ПК" -->
                                <div class="dropdown-content" id="pc">
                                    <ul class="brands-grid">
                                        <li><a href="#">Сборка ПК</a></li>
                                        <li><a href="#">Чистка от пыли</a></li>
                                        <li><a href="#">Апгрейд</a></li>
                                        <li><a href="#">Замена термопасты</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- Конец выпадающего меню -->
                </li>
                <li class="with-childs">
                    <a href="">
                        Ремонт 
                        <br><span>оргтехники</span>
                    </a>
                </li>
                <li class="with-childs">
                    <a href="">
                        Ремонт 
                        <br><span>бытовой техники</span>
                    </a>
                </li>
                <li>
                    <a href="">
                        <span>Самодиагностика</span>
                    </a>
                </li>
            </ul>

            <div class="header__city">
                <button>
                    <svg class="fs" width="12" height="16" viewBox="0 0 12 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M6.74062 15.6C8.34375 13.5938 12 8.73125 12 6C12 2.6875 9.3125 0 6 0C2.6875 0 0 2.6875 0 6C0 8.73125 3.65625 13.5938 5.25938 15.6C5.64375 16.0781 6.35625 16.0781 6.74062 15.6ZM6 4C6.53043 4 7.03914 4.21071 7.41421 4.58579C7.78929 4.96086 8 5.46957 8 6C8 6.53043 7.78929 7.03914 7.41421 7.41421C7.03914 7.78929 6.53043 8 6 8C5.46957 8 4.96086 7.78929 4.58579 7.41421C4.21071 7.03914 4 6.53043 4 6C4 5.46957 4.21071 4.96086 4.58579 4.58579C4.96086 4.21071 5.46957 4 6 4Z" fill="#FFBE42" />
                    </svg>
                    Омск
                </button>
            </div>

            <!-- Скрытая форма поиска -->
            <div class="search-panel js-search-panel">
                <div class="container search-panel__container">
                    <form action="/search/" method="get" class="search-panel__form">
                        <!-- Иконка поиска (кнопка сабмита) -->
                        <button type="submit" class="search-panel__submit">
                            <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.07378 11.2472C9.32366 11.2472 11.1476 9.36575 11.1476 7.04489C11.1476 4.72402 9.32366 2.84259 7.07378 2.84259C4.82389 2.84259 3 4.72402 3 7.04489C3 9.36575 4.82389 11.2472 7.07378 11.2472Z" stroke="currentColor" stroke-width="1.5"/>
                                <path d="M10.0391 10.1012L13.0018 13.1574" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        
                        <!-- Поле ввода -->
                        <input type="text" name="q" class="search-panel__input js-search-input" placeholder="Что вы ищете?" autocomplete="off">
                        
                        <!-- Кнопка закрыть -->
                        <button type="button" class="search-panel__close js-search-close">
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1L13 13M13 1L1 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</header>

<div class="panel-adaptive">
    <ul>
        <li><a href="">Ремонт <span>техники Apple</span></a></li>
        <li><a href="">Ремонт <span>техники Apple</span></a></li>
        <li><a href="">Ремонт <span>техники Apple</span></a></li>
        <li><a href="">Ремонт <span>техники Apple</span></a></li>
        <li><a href="">Ремонт <span>техники Apple</span></a></li>
        <li><a href="">Ремонт <span>техники Apple</span></a></li>
    </ul>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. Логика открытия/закрытия меню по клику
    const menuParents = document.querySelectorAll('.js-dropdown-parent');

    menuParents.forEach(parent => {
        const toggleBtn = parent.querySelector('.js-dropdown-toggle');
        
        // Клик по ссылке меню
        toggleBtn.addEventListener('click', function(e) {
            e.preventDefault(); // Отменяем переход по ссылке
            
            // Закрываем другие открытые меню, если есть
            menuParents.forEach(item => {
                if (item !== parent) item.classList.remove('is-open');
            });

            // Тоглим текущее
            parent.classList.toggle('is-open');
        });
    });

    // Закрытие при клике вне меню
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.js-dropdown-parent')) {
            menuParents.forEach(parent => parent.classList.remove('is-open'));
        }
    });


    // 2. Логика переключения табов внутри меню
    const tabs = document.querySelectorAll('.dropdown-tab');

    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Находим родительский контейнер меню (чтобы не путать табы разных меню)
            const menuContainer = this.closest('.dropdown-menu');
            const targetId = this.getAttribute('data-tab');

            // Убираем активность у всех табов и контента в этом меню
            menuContainer.querySelectorAll('.dropdown-tab').forEach(t => t.classList.remove('is-active'));
            menuContainer.querySelectorAll('.dropdown-content').forEach(c => c.classList.remove('is-active'));

            // Активируем нажатый таб
            this.classList.add('is-active');
            
            // Активируем соответствующий контент
            const content = menuContainer.querySelector(`#${targetId}`);
            if (content) {
                content.classList.add('is-active');
            }
        });
    });
});
</script>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const searchTrigger = document.querySelector('.js-search');
    const searchPanel = document.querySelector('.js-search-panel');
    const searchInput = document.querySelector('.js-search-input');
    const closeBtn = document.querySelector('.js-search-close');

    // Функция открытия
    const openSearch = (e) => {
        e.preventDefault();
        searchPanel.classList.add('is-active');
        // Небольшая задержка, чтобы анимация CSS успела отработать перед фокусом
        setTimeout(() => {
            searchInput.focus();
        }, 100);
    };

    // Функция закрытия
    const closeSearch = () => {
        searchPanel.classList.remove('is-active');
    };

    // События
    if (searchTrigger && searchPanel) {
        
        // 1. Клик по кнопке "Поиск" в шапке
        searchTrigger.addEventListener('click', openSearch);

        // 2. Клик по кнопке "Закрыть" (крестик)
        closeBtn.addEventListener('click', closeSearch);

        // 3. Закрытие при клике вне области формы (Body click)
        document.addEventListener('click', (e) => {
            const isClickInsideSearch = searchPanel.contains(e.target);
            const isClickOnTrigger = searchTrigger.contains(e.target);

            // Если клик не внутри панели И не по кнопке открытия — закрываем
            if (!isClickInsideSearch && !isClickOnTrigger && searchPanel.classList.contains('is-active')) {
                closeSearch();
            }
        });

        // 4. Закрытие по клавише Esc (UX best practice)
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && searchPanel.classList.contains('is-active')) {
                closeSearch();
            }
        });
    }
});
</script>
