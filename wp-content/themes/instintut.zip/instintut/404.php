<?php get_header(); ?>

<div class="content">
	<div class="container">
		<div class="card">
			<?php breadcrumbs('404 - Страница не найдена') ?>

			<h1>404</h1>

			<p style="margin-bottom: 40px;">
				Страница не найдена
			</p>
			
		</div>
	</div>
</div>

<?php get_footer(); ?>
