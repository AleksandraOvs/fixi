<?php
// 1. Получаем все категории устройств (родительские страницы CPT 'device')
$device_categories = get_posts(array(
    'post_type'      => 'device',
    'post_parent'    => 0,
    'posts_per_page' => -1,
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
));

// 2. Формируем массив данных для JS (Категория -> Модели -> Поломки)
$js_repair_data = array();

foreach ($device_categories as $cat) {
    // Получаем модели (дочерние для категории)
    $models = get_posts(array(
        'post_type'      => 'device',
        'post_parent'    => $cat->ID,
        'posts_per_page' => -1,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
    ));

    $models_list = array();
    $problems_list = array(); // Собираем уникальные поломки со всех моделей этой категории

    foreach ($models as $model) {
        $models_list[$model->ID] = $model->post_title; // ID для value, Title для текста

        // Получаем поломки (дочерние для модели)
        $problems = get_posts(array(
            'post_type'      => 'device',
            'post_parent'    => $model->ID,
            'posts_per_page' => -1,
        ));

        foreach ($problems as $prob) {
            // Используем название поломки как ключ, чтобы избежать дублей
            // Или можно собирать ID, если нужна ссылка на конкретную страницу
            $problems_list[$prob->post_title] = $prob->post_title;
        }
    }

    // Сохраняем в структуру для JS
    // Используем slug категории как ключ
    $js_repair_data[$cat->post_name] = array(
        'name'     => $cat->post_title,
        'models'   => array_values($models_list), // Просто массив названий для селекта
        'problems' => array_values($problems_list)
    );
}

// 3. Получаем популярные модели для нижнего блока тегов
// Можно настроить логику: например, последние добавленные или помеченные метаполем
// Здесь просто берем последние 30 моделей со всех категорий
$popular_models = get_posts(array(
    'post_type'      => 'device',
    'posts_per_page' => 28,
    // Исключаем категории (родитель = 0)
    'post_parent__not_in' => array(0), 
    // Нужно исключить и поломки (уровень 3). 
    // Сложный запрос, проще проверить post_parent в цикле или использовать depth если бы это был get_pages
    // В данном упрощенном варианте просто берем все не-корневые.
    // Для точности лучше использовать get_pages с child_of для каждой категории, но это медленно.
    // Оптимально: добавить метаполе 'is_popular' к нужным моделям.
));

// Фильтр только 2-го уровня (модели) вручную, если структура строгая
$filtered_popular = array();
foreach ($popular_models as $p) {
    if ($p->post_parent != 0) { // Это не категория
        $grandparent = wp_get_post_parent_id($p->post_parent);
        if ($grandparent == 0) { // Значит родитель - категория => это модель
            $filtered_popular[] = $p;
        }
    }
}
?>

<div class="hero__search-box m-100">

    <div class="container">
        <!-- ФОРМА ПОИСКА -->
        <form class="search-form" id="repair-calculator-form" action="/search-repair/" method="GET">
            <!-- 1. Вид устройства -->
            <select class="search-form__input" id="device-type" name="device_type">
                <option value="" disabled selected>Вид устройства</option>
                <?php foreach ($device_categories as $cat): ?>
                    <option value="<?php echo esc_attr($cat->post_name); ?>">
                        <?php echo esc_html($cat->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <!-- 2. Модель -->
            <select class="search-form__input" id="device-model" name="device_model" disabled>
                <option value="" selected>Модель</option>
            </select>

            <!-- 3. Поломка -->
            <select class="search-form__input" id="device-problem" name="device_problem" disabled>
                <option value="" selected>Что сломалось</option>
            </select>

            <button type="submit" class="btn btn--orange search-form__btn">Узнать стоимость ремонта</button>
        </form>

        <!-- JS ЛОГИКА -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Данные из PHP
            const repairData = <?php echo json_encode($js_repair_data); ?>;

            // Элементы формы
            const typeSelect = document.getElementById('device-type');
            const modelSelect = document.getElementById('device-model');
            const problemSelect = document.getElementById('device-problem');

            // Функция заполнения select
            function populateSelect(selectElement, options, defaultLabel) {
                selectElement.innerHTML = `<option value="" selected>${defaultLabel}</option>`;
                selectElement.disabled = !options || options.length === 0;
                
                if (options) {
                    options.forEach(opt => {
                        const option = document.createElement('option');
                        option.value = opt; // Здесь можно передавать ID или Slug, если нужно для формы
                        option.textContent = opt;
                        selectElement.appendChild(option);
                    });
                }
            }

            // Обработчик смены устройства
            typeSelect.addEventListener('change', function() {
                const selectedType = this.value;
                const data = repairData[selectedType];

                if (data) {
                    populateSelect(modelSelect, data.models, "Выберите модель");
                    // Сбрасываем поломки при смене устройства
                    populateSelect(problemSelect, [], "Что сломалось"); 
                    // Можно сразу загрузить все возможные поломки категории, 
                    // или ждать выбора модели (если поломки зависят от модели, нужно усложнить структуру JS)
                    populateSelect(problemSelect, data.problems, "Выберите поломку");
                } else {
                    populateSelect(modelSelect, [], "Модель");
                    populateSelect(problemSelect, [], "Что сломалось");
                }
            });
            
            // (Опционально) Обработчик отправки
            document.getElementById('repair-calculator-form').addEventListener('submit', function(e) {
                // Здесь можно перенаправить на страницу выбранной модели/поломки
                // e.preventDefault();
                // Логика редиректа...
            });
        });
        </script>

        <!-- БЛОК СЕТКИ УСЛУГ (ПЛИТКИ) -->
        <div class="hero__services">
            <h2 class="hero__services-title">
                мы ремонтируем технику
                <br>любой сложности!
            </h2>
            <div class="hero__services-sub">
                выберите тип устройства
            </div>
        
            <div class="row">
                <?php 
                // Определяем классы колонок для сетки (примерный паттерн из вашей верстки)
                // Можно сделать динамически или задать вручную через ACF для каждой категории
                $col_classes = ['col-2', 'col-2', 'col-2', 'col-6', 'col-2', 'col-2', 'col-2', 'col-3', 'col-3', 'col-6', 'col-2', 'col-2', 'col-2'];
                $i = 0;
                
                foreach ($device_categories as $cat): 
                    // Картинка: можно использовать Featured Image (thumbnail) поста
                    $img_url = get_the_post_thumbnail_url($cat->ID, 'full'); 
                    if (!$img_url) {
                         // Заглушка, если нет картинки. Индекс +1 для соответствия вашим именам файлов
                         $img_index = $i + 1;
                         $img_url = "/img/service/{$img_index}.png"; 
                    }
                    
                    $col_class = isset($col_classes[$i]) ? $col_classes[$i] : 'col-2';
                ?>
                    <div class="<?php echo esc_attr($col_class); ?>">
                        <a class="service-item" href="<?php echo get_permalink($cat->ID); ?>">
                            <div class="service-item__img">
                                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($cat->post_title); ?>">
                            </div>
                            <span><?php echo $cat->post_title; // Можно использовать nl2br если в названиях есть переносы ?></span>
                        </a>
                    </div>
                <?php 
                    $i++; 
                endforeach; 
                ?>
            </div>
        </div>

        <!-- БЛОК ПОПУЛЯРНЫХ МОДЕЛЕЙ (ТЕГИ) -->
        <div class="hero__tags">
            <h2>
                ремонтируем популярные 
                <br>модели техники.
                <br><span>выберите вашу модель</span>
            </h2>

            <div class="tags-list__in">
                <ul class="tags-list">
                    <?php if (!empty($filtered_popular)): ?>
                        <?php foreach ($filtered_popular as $model): ?>
                            <li>
                                <a href="<?php echo get_permalink($model->ID); ?>">
                                    <?php echo esc_html($model->post_title); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- Фоллбек, если ничего не найдено -->
                        <li><a href="#">Нет популярных моделей</a></li>
                    <?php endif; ?>
                    
                    <!-- Статическая ссылка "Нет нужного" -->
                    <li><a href="/contacts/">Нет нужного</a></li>
                </ul>
            </div>
        </div>
    </div>

</div>