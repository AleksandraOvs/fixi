<div class="features p-100">

    <div class="features__list">
        <div class="container">
            <h2 class="h2_center">
                Почему
                <br>жители Омска доверяют Fixibot?
                <br><span>Наши преимущества</span>
            </h2>

            <div class="features__row row m-2">
                <div class="col-3">
                    <div class="feature-item">
                        <div class="feature-item__icon">
                            <img src="/img/features/1.png" alt="">
                        </div>
                        <div class="feature-item__content">
                            <div class="feature-item__title">
                                Опыт
                            </div>
                            <div class="feature-item__sub">
                                Мастера с опытом от 5 лет.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="feature-item">
                        <div class="feature-item__icon">
                            <img src="/img/features/2.png" alt="">
                        </div>
                        <div class="feature-item__content">
                            <div class="feature-item__title">
                                Удобство
                            </div>
                            <div class="feature-item__sub">
                                Работаем 
                                ежедневно с 10:00 до 20:00.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="feature-item">
                        <div class="feature-item__icon">
                            <img src="/img/features/3.png" alt="">
                        </div>
                        <div class="feature-item__content">
                            <div class="feature-item__title">
                                Скорость
                            </div>
                            <div class="feature-item__sub">
                                80% ремонтов — в день обращения.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="features__row m-2 row">
                <div class="col-3">
                    <div class="feature-item">
                        <div class="feature-item__icon">
                            <img src="/img/features/4.png" alt="">
                        </div>
                        <div class="feature-item__content">
                            <div class="feature-item__title">
                                Качество
                            </div>
                            <div class="feature-item__sub">
                                Оригинальные 
                                или сертифицированные запчасти.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="feature-item">
                        <div class="feature-item__icon">
                            <img src="/img/features/5.png" alt="">
                        </div>
                        <div class="feature-item__content">
                            <div class="feature-item__title">
                                Гарантия
                            </div>
                            <div class="feature-item__sub">
                                До 12 месяцев на работы и запчасти.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="feature-item">
                        <div class="feature-item__icon">
                            <img src="/img/features/6.png" alt="">
                        </div>
                        <div class="feature-item__content">
                            <div class="feature-item__title">
                                Прозрачность
                            </div>
                            <div class="feature-item__sub">
                                Стоимость фиксируется до ремонта.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="feature-item">
                        <div class="feature-item__icon feature-item__icon-last">
                            <img src="/img/features/7.png" alt="">
                        </div>
                        <div class="feature-item__content">
                            <div class="feature-item__title">
                                Прозрачность
                            </div>
                            <div class="feature-item__sub">
                                Стоимость фиксируется до ремонта.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>