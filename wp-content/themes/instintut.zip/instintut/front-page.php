<?php 
/* Template Name: Главная */
get_header();

?>

<div class="main">
    <div class="hero">
        <div class="container">
            <div class="hero__in">
                <div class="hero__title">
                    <span>Fixibot</span>
                    <br> ваш надежный
                    <br> ремонт техники
                    <br> в Омске!
                </div>

                <div class="hero__features">
                    <div class="hero__feature hero__feature-top">
                        <svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_437_22919)">
                        <path d="M24 6.32912C23.7222 6.61095 23.4672 6.87265 23.2082 7.13167C22.0084 8.33012 20.8046 9.5259 19.6061 10.727C18.8666 11.4679 18.0064 12.0168 17.0119 12.3295C16.3516 12.5361 15.6685 12.6435 14.968 12.6395C12.9898 12.6301 11.0116 12.6301 9.03338 12.6395C8.35564 12.6422 7.69401 12.5455 7.05251 12.3536C6.18822 12.0959 5.39775 11.6786 4.73612 11.0585C4.12414 10.4868 3.53498 9.89094 2.94045 9.30043C2.04664 8.41199 1.15685 7.51684 0.265727 6.62571C0.179836 6.53982 0.0966281 6.45125 0 6.35059C0.0496561 6.27678 0.0818655 6.20565 0.132864 6.15465C1.65073 4.64215 3.16323 3.12294 4.69586 1.62521C5.27697 1.05752 5.98289 0.673691 6.75189 0.403938C7.57323 0.115396 8.4147 -0.00136341 9.28032 0.0013207C11.2142 0.00803098 13.1468 -0.00941575 15.0807 0.00803098C15.7719 0.0147413 16.4456 0.154315 17.1112 0.36636C18.2681 0.734084 19.1646 1.46014 19.9966 2.30429C21.2421 3.56851 22.5036 4.81796 23.7571 6.07413C23.8336 6.15062 23.9074 6.23115 24 6.32912ZM12.0678 10.7834C12.9723 10.7834 13.8782 10.7861 14.7828 10.7834C15.749 10.7807 16.6657 10.5995 17.4924 10.0627C18.5835 9.35546 19.2397 8.34623 19.4773 7.08872C19.6893 5.96139 19.4558 4.89178 18.8223 3.92549C17.9715 2.62773 16.7529 1.92449 15.2136 1.89228C13.0582 1.84665 10.9015 1.87081 8.74484 1.89094C8.3382 1.89496 7.92082 1.97951 7.52894 2.09761C6.66063 2.35797 5.94934 2.87198 5.38836 3.58327C4.91059 4.18988 4.59118 4.87701 4.49186 5.64333C4.39524 6.39085 4.43147 7.13167 4.71062 7.85235C5.07297 8.79045 5.66482 9.52858 6.50629 10.0761C7.31287 10.6009 8.2107 10.7767 9.15283 10.7834C10.1245 10.7901 11.0961 10.7847 12.0691 10.7847L12.0678 10.7834Z" fill="white"/>
                        <path d="M13.034 6.3578C12.9723 5.28147 13.956 4.28835 15.031 4.2709C16.1878 4.25077 17.1608 5.15263 17.1675 6.29472C17.1743 7.39923 16.3932 8.37625 15.0954 8.38833C13.8849 8.40041 13.0313 7.41668 13.034 6.3578Z" fill="white"/>
                        <path d="M8.88882 4.28145C10.0068 4.22106 10.961 5.237 10.9462 6.3348C10.9314 7.40576 10.1168 8.37607 8.90224 8.38815C7.61386 8.40023 6.81534 7.36953 6.80863 6.31467C6.80192 5.23566 7.75746 4.21435 8.88882 4.28145Z" fill="white"/>
                        </g>
                        <defs>
                        <clipPath id="clip0_437_22919">
                        <rect width="24" height="12.6396" fill="white"/>
                        </clipPath>
                        </defs>
                        </svg>
                        Срочный ремонт от 30 минут
                    </div>
                    <div class="hero__feature hero__feature-bottom">
                        <svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_437_22919)">
                        <path d="M24 6.32912C23.7222 6.61095 23.4672 6.87265 23.2082 7.13167C22.0084 8.33012 20.8046 9.5259 19.6061 10.727C18.8666 11.4679 18.0064 12.0168 17.0119 12.3295C16.3516 12.5361 15.6685 12.6435 14.968 12.6395C12.9898 12.6301 11.0116 12.6301 9.03338 12.6395C8.35564 12.6422 7.69401 12.5455 7.05251 12.3536C6.18822 12.0959 5.39775 11.6786 4.73612 11.0585C4.12414 10.4868 3.53498 9.89094 2.94045 9.30043C2.04664 8.41199 1.15685 7.51684 0.265727 6.62571C0.179836 6.53982 0.0966281 6.45125 0 6.35059C0.0496561 6.27678 0.0818655 6.20565 0.132864 6.15465C1.65073 4.64215 3.16323 3.12294 4.69586 1.62521C5.27697 1.05752 5.98289 0.673691 6.75189 0.403938C7.57323 0.115396 8.4147 -0.00136341 9.28032 0.0013207C11.2142 0.00803098 13.1468 -0.00941575 15.0807 0.00803098C15.7719 0.0147413 16.4456 0.154315 17.1112 0.36636C18.2681 0.734084 19.1646 1.46014 19.9966 2.30429C21.2421 3.56851 22.5036 4.81796 23.7571 6.07413C23.8336 6.15062 23.9074 6.23115 24 6.32912ZM12.0678 10.7834C12.9723 10.7834 13.8782 10.7861 14.7828 10.7834C15.749 10.7807 16.6657 10.5995 17.4924 10.0627C18.5835 9.35546 19.2397 8.34623 19.4773 7.08872C19.6893 5.96139 19.4558 4.89178 18.8223 3.92549C17.9715 2.62773 16.7529 1.92449 15.2136 1.89228C13.0582 1.84665 10.9015 1.87081 8.74484 1.89094C8.3382 1.89496 7.92082 1.97951 7.52894 2.09761C6.66063 2.35797 5.94934 2.87198 5.38836 3.58327C4.91059 4.18988 4.59118 4.87701 4.49186 5.64333C4.39524 6.39085 4.43147 7.13167 4.71062 7.85235C5.07297 8.79045 5.66482 9.52858 6.50629 10.0761C7.31287 10.6009 8.2107 10.7767 9.15283 10.7834C10.1245 10.7901 11.0961 10.7847 12.0691 10.7847L12.0678 10.7834Z" fill="white"/>
                        <path d="M13.034 6.3578C12.9723 5.28147 13.956 4.28835 15.031 4.2709C16.1878 4.25077 17.1608 5.15263 17.1675 6.29472C17.1743 7.39923 16.3932 8.37625 15.0954 8.38833C13.8849 8.40041 13.0313 7.41668 13.034 6.3578Z" fill="white"/>
                        <path d="M8.88882 4.28145C10.0068 4.22106 10.961 5.237 10.9462 6.3348C10.9314 7.40576 10.1168 8.37607 8.90224 8.38815C7.61386 8.40023 6.81534 7.36953 6.80863 6.31467C6.80192 5.23566 7.75746 4.21435 8.88882 4.28145Z" fill="white"/>
                        </g>
                        <defs>
                        <clipPath id="clip0_437_22919">
                        <rect width="24" height="12.6396" fill="white"/>
                        </clipPath>
                        </defs>
                        </svg>
                        Бесплатная диагностика за 15 минут 
                    </div>
                </div>

                <div class="hero__img">
                    <img src="/img/bot.png" alt="">
                </div>
            </div>
        </div>
    </div>
    
    <div class="hero__search-box m-100">

        <div class="container">
            <form class="search-form">
                <!-- 1. Вид устройства -->
                <select class="search-form__input" id="device-type" name="device_type">
                    <option value="" disabled selected>Вид устройства</option>
                    <option value="iphone">iPhone</option>
                    <option value="phone">Телефоны (Android)</option>
                    <option value="macbook">MacBook</option>
                    <option value="laptop">Ноутбуки</option>
                    <option value="tablet">Планшеты</option>
                    <option value="console">Игровые приставки</option>
                    <option value="printer">Принтеры / МФУ</option>
                    <option value="cartridge">Заправка картриджей</option>
                </select>

                <!-- 2. Модель (зависит от устройства) -->
                <select class="search-form__input" id="device-model" name="device_model" disabled>
                    <option value="" selected>Модель</option>
                </select>

                <!-- 3. Что сломалось (зависит от устройства) -->
                <select class="search-form__input" id="device-problem" name="device_problem" disabled>
                    <option value="" selected>Что сломалось</option>
                </select>

                <button class="btn btn--orange search-form__btn">Узнать стоимость ремонта</button>
            </form>

            <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Тестовые данные: Устройство -> { Модели, Проблемы }
                const repairData = {
                    "iphone": {
                        models: ["iPhone 16 / 16 Pro", "iPhone 15 / 15 Pro", "iPhone 14 / 14 Pro", "iPhone 13 / 13 mini", "iPhone 12 / 12 Pro", "iPhone 11", "iPhone XR / XS", "iPhone SE 2020/22"],
                        problems: ["Замена дисплея (оригинал)", "Замена стекла (переклейка)", "Замена аккумулятора", "Не включается / не заряжается", "Ремонт FaceID", "Замена заднего стекла", "Чистка после воды"]
                    },
                    "phone": {
                        models: ["Samsung Galaxy S23 / S24", "Samsung A-series (A35/A55)", "Xiaomi Redmi Note 13", "Poco X6 / F5", "Huawei P60 / Mate 50", "Honor 90 / X9b", "Realme 11 / 12 Pro"],
                        problems: ["Замена экрана", "Замена разъема зарядки", "Быстро разряжается", "Сброс Google аккаунта", "Прошивка / Висит на логотипе", "Замена микрофона/динамика"]
                    },
                    "macbook": {
                        models: ["MacBook Air M1/M2", "MacBook Pro 14/16 (M1/M2/M3)", "MacBook Pro 13 (TouchBar)", "MacBook Air 13 (2018-2020)", "MacBook Pro Retina 13/15 (2012-2015)"],
                        problems: ["Чистка и замена термопасты", "Замена матрицы", "Ремонт клавиатуры (залипание)", "Замена аккумулятора", "Восстановление цепей питания", "Установка macOS"]
                    },
                    "laptop": {
                        models: ["Asus TUF / ROG", "Acer Nitro / Aspire", "Lenovo Legion / IdeaPad", "HP Pavilion / Omen", "Dell G-series / XPS", "MSI Katana / Raider"],
                        problems: ["Чистка от пыли", "Замена жесткого диска на SSD", "Ремонт петель корпуса", "Замена матрицы экрана", "Ремонт материнской платы", "Не включается"]
                    },
                    "tablet": {
                        models: ["iPad Pro 11/12.9 (M1/M2)", "iPad Air 4/5", "iPad 10.2 (9/10 gen)", "Samsung Galaxy Tab S9/S8", "Xiaomi Pad 5/6"],
                        problems: ["Замена сенсорного стекла", "Замена дисплея в сборе", "Замена аккумулятора", "Ремонт разъема Type-C/Lightning", "Восстановление ПО"]
                    },
                    "console": {
                        models: ["Sony PlayStation 5", "Sony PlayStation 4 (Fat/Slim/Pro)", "Xbox Series X / S", "Nintendo Switch / OLED", "Steam Deck"],
                        problems: ["Чистка от пыли (шумит)", "Ремонт геймпада (дрифт стиков)", "Замена HDMI разъема", "Ошибка программного обеспечения", "Ремонт блока питания"]
                    },
                    "printer": {
                        models: ["HP LaserJet (Лазерные)", "Canon i-SENSYS", "Epson L-серия (Струйные)", "Kyocera ECOSYS", "Brother DCP"],
                        problems: ["Замятие бумаги", "Бледная печать / полосы", "Замена термопленки", "Сброс абсорбера (памперса)", "Не захватывает бумагу"]
                    },
                    "cartridge": {
                        models: ["HP (CB435A/436A/285A)", "Canon (725/712/728)", "Brother (TN-1075/2090)", "Samsung (D101/D111)", "Xerox / Pantum"],
                        problems: ["Заправка тонером", "Замена фотобарабана", "Замена магнитного вала", "Замена чипа", "Восстановление картриджа"]
                    }
                };

                // Элементы формы
                const typeSelect = document.getElementById('device-type');
                const modelSelect = document.getElementById('device-model');
                const problemSelect = document.getElementById('device-problem');

                // Функция очистки и заполнения select
                function populateSelect(selectElement, options, defaultLabel) {
                    selectElement.innerHTML = `<option value="" selected>${defaultLabel}</option>`;
                    selectElement.disabled = !options || options.length === 0;
                    
                    if (options) {
                        options.forEach(opt => {
                            const option = document.createElement('option');
                            option.value = opt;
                            option.textContent = opt;
                            selectElement.appendChild(option);
                        });
                    }
                }

                // Слушатель изменений типа устройства
                typeSelect.addEventListener('change', function() {
                    const selectedType = this.value;
                    const data = repairData[selectedType];

                    if (data) {
                        // 1. Заполняем модели
                        populateSelect(modelSelect, data.models, "Выберите модель");
                        // 2. Заполняем поломки (обычно зависят от типа устройства, а не конкретной модели)
                        populateSelect(problemSelect, data.problems, "Выберите поломку");
                    } else {
                        // Сброс, если ничего не выбрано
                        populateSelect(modelSelect, [], "Модель");
                        populateSelect(problemSelect, [], "Что сломалось");
                    }
                });
            });
            </script>

            <div class="hero__services">
                <h2 class="hero__services-title">
                    мы ремонтируем технику
                    <br>любой сложности!
                </h2>
                <div class="hero__services-sub">
                    выберите тип устройства
                </div>
            
                <div class="row">
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/1.png" alt="">
                            </div>
                            <span>Iphone</span>
                        </a>
                    </div>
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/2.png" alt="">
                            </div>
                            <span>Телефоны</span>
                        </a>
                    </div>
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/3.png" alt="">
                            </div>
                            <span>MacBook</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/4.png" alt="">
                            </div>
                            <span>Заправка картриджей</span>
                        </a>
                    </div>
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/5.png" alt="">
                            </div>
                            <span>Ноутбуки</span>
                        </a>
                    </div>
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/6.png" alt="">
                            </div>
                            <span>Планшеты</span>
                        </a>
                    </div>
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/7.png" alt="">
                            </div>
                            <span>Телевизор</span>
                        </a>
                    </div>
                    <div class="col-3">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/8.png" alt="">
                            </div>
                            <span>Игровые<br> приставки</span>
                        </a>
                    </div>
                    <div class="col-3">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/9.png" alt="">
                            </div>
                            <span>Материнские<br> платы</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/10.png" alt="">
                            </div>
                            <span>Компьютеры</span>
                        </a>
                    </div>
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/11.png" alt="">
                            </div>
                            <span>Моноблоки</span>
                        </a>
                    </div>
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/12.png" alt="">
                            </div>
                            <span>МФУ</span>
                        </a>
                    </div>
                    <div class="col-2">
                        <a class="service-item" href="#">
                            <div class="service-item__img">
                                <img src="/img/service/13.png" alt="">
                            </div>
                            <span>Принтеры</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="hero__tags">
                <h2>
                    ремонтируем популярные 
                    <br>модели техники.
                    <br><span>выберите вашу модель</span>
                </h2>

                <div class="tags-list__in">
                    <ul class="tags-list">
                        <li><a href="">iPhone 11</a></li>
                        <li><a href="">iPhone 12</a></li>
                        <li><a href="">iPhone 13</a></li>
                        <li><a href="">iPhone 14</a></li>
                        <li><a href="">iPad Pro</a></li>
                        <li><a href="">iPad Air</a></li>
                        <li><a href="">MacBook Pro</a></li>
                        <li><a href="">Xiaomi Redmi Note</a></li>
                        <li><a href="">Samsung galaxy a series</a></li>
                        <li><a href="">Samsung galaxy B series</a></li>
                        <li><a href="">MacBook Air</a></li>
                        <li><a href="">Asus ROG</a></li>
                        <li><a href="">Lenovo ThinkPad</a></li>
                        <li><a href="">Huawei P series</a></li>
                        <li><a href="">LG Smart TV</a></li>
                        <li><a href="">Samsung QLED</a></li>
                        <li><a href="">Sony Bravia</a></li>
                        <li><a href="">PlayStation 4</a></li>
                        <li><a href="">HP Pavilion</a></li>
                        <li><a href="">Samsung Galacse Tab</a></li>
                        <li><a href="">Nintendo Switch</a></li>
                        <li><a href="">PlayStation 5</a></li>
                        <li><a href="">Xbox Series X</a></li>
                        <li><a href="">Canon PIXMA</a></li>
                        <li><a href="">HP LaserJet</a></li>
                        <li><a href="">Epson WorkForce</a></li>
                        <li><a href="">Нет нужного</a></li>
                    </ul>
                </div>

            </div>
        </div>

    </div>

    <?php get_template_part('parts/search-box'); ?>

    <div class="features p-100">

        <div class="features__circle"></div>

        <div class="features__list">
            <div class="container">
                <h2 class="h2_center">
                    Почему
                    <br>жители Омска доверяют Fixibot?
                    <br><span>Наши преимущества</span>
                </h2>

                <div class="features__row row m-2">
                    <div class="col-3">
                        <div class="feature-item">
                            <div class="feature-item__icon">
                                <img src="/img/features/1.png" alt="">
                            </div>
                            <div class="feature-item__content">
                                <div class="feature-item__title">
                                    Опыт
                                </div>
                                <div class="feature-item__sub">
                                    Мастера с опытом от 5 лет.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="feature-item">
                            <div class="feature-item__icon">
                                <img src="/img/features/2.png" alt="">
                            </div>
                            <div class="feature-item__content">
                                <div class="feature-item__title">
                                    Удобство
                                </div>
                                <div class="feature-item__sub">
                                    Работаем 
                                    ежедневно с 10:00 до 20:00.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="feature-item">
                            <div class="feature-item__icon">
                                <img src="/img/features/3.png" alt="">
                            </div>
                            <div class="feature-item__content">
                                <div class="feature-item__title">
                                    Скорость
                                </div>
                                <div class="feature-item__sub">
                                    80% ремонтов — в день обращения.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="features__row m-2 row">
                    <div class="col-3">
                        <div class="feature-item">
                            <div class="feature-item__icon">
                                <img src="/img/features/4.png" alt="">
                            </div>
                            <div class="feature-item__content">
                                <div class="feature-item__title">
                                    Качество
                                </div>
                                <div class="feature-item__sub">
                                    Оригинальные 
                                    или сертифицированные запчасти.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="feature-item">
                            <div class="feature-item__icon">
                                <img src="/img/features/5.png" alt="">
                            </div>
                            <div class="feature-item__content">
                                <div class="feature-item__title">
                                    Гарантия
                                </div>
                                <div class="feature-item__sub">
                                    До 12 месяцев на работы и запчасти.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="feature-item">
                            <div class="feature-item__icon">
                                <img src="/img/features/6.png" alt="">
                            </div>
                            <div class="feature-item__content">
                                <div class="feature-item__title">
                                    Прозрачность
                                </div>
                                <div class="feature-item__sub">
                                    Стоимость фиксируется до ремонта.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="feature-item">
                            <div class="feature-item__icon feature-item__icon-last">
                                <img src="/img/features/7.png" alt="">
                            </div>
                            <div class="feature-item__content">
                                <div class="feature-item__title">
                                    Прозрачность
                                </div>
                                <div class="feature-item__sub">
                                    Стоимость фиксируется до ремонта.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="bg-wrapper">
        <div class="about">
            <div class="container">
                <div class="row auto-h">
                    <div class="col-6">
                        <div class="about__item">
                            <h2>
                                о нас
                                <br> <span>кто такие Fixibot?</span>
                            </h2>
                            <div class="about__text">
                                Мы работаем в сфере ремонта техники в Омске уже более 16 лет и зарекомендовали себя как надежный сервисный центр. 
        В нашей команде работают только квалифицированные инженеры с многолетним опытом, что обеспечивает высокий уровень обслуживания. В 95% случаев профессиональный ремонт оказывается выгоднее покупки новой техники, и мы это подтверждаем на деле. Быстрая диагностика и использование только оригинальных запчастей позволяют нам выполнять большинство работ за 1-2 дня. Обратившись к нам, вы получите качественный ремонт, которым можно доверять.
                            </div>
                            <div class="about__sub">
                                Не откладывайте ремонт! 
        Звоните прямо сейчас!
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="about__item about__item-blue">
                            <h2 class="about-item__title">
                                Наша миссия — 
                            </h2>
                            <div class="about-item__sub">
                                продлевать жизнь вашим устройствам, помогая вам экономить время и деньги
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="reviews">
            
            <div class="container">
        
                <div class="reviews__in">
                    <div class="reviews__header">
                        <div class="reviews__header-in">
                            <h2>
                                Что говорят 
                                <br>наши
                                <br>клиенты
                                <br><span>Отзывы</span>
                            </h2>
                            
                            <div class="reviews__count-title">
                                <div class="reviews__rait-title">
                                    Отзывы с Яндекс карт:
                                </div>
                                <div class="reviews__rait-count">
                                    <div class="reviews__stars fs">
                                        <img src="/img/stars.svg" alt="">
                                    </div>
                                    <div class="reviews__count">
                                        4.9
                                    </div>
                                </div>
                            </div>
                            <div class="reviews__add-review">
                                <a href="#" class="btn">Оценить работу</a>
                            </div>
                        </div>
                    </div>
                    <div class="reviews-slider swiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="review-item">
                                    <div class="review-item__header">
                                        <div class="review-item__name">
                                            Анна
                                            <br>34 года
                                        </div>
                                        <div class="review-item__logo">
                                            <img src="/img/logos/ya.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="review-item__quote-top">
                                        <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_437_23355)">
                                        <path d="M17.8439 2.65757C15.6072 3.7071 9.32545 7.54546 7.78917 14.7364H14.8804C16.3289 14.7364 17.5031 15.8947 17.5031 17.3237V29.4124C17.5031 30.8415 16.3289 31.9998 14.8804 31.9998H2.62271C1.17414 31.9998 0 30.8415 0 29.4124V21.4934H0.00125308C0.174179 6.78768 12.5872 1.456 16.7926 0.0714629C17.5394 -0.174539 18.3452 0.230931 18.5795 0.972645L18.5857 0.991188C18.795 1.65131 18.4767 2.36089 17.8439 2.65757Z" fill="#EDF6FF"/>
                                        <path d="M44.3947 2.65757C42.1579 3.7071 35.8762 7.54546 34.34 14.7364H41.4312C42.8797 14.7364 44.0539 15.8947 44.0539 17.3237V29.4124C44.0539 30.8415 42.8797 31.9998 41.4312 31.9998H29.1735C27.7249 31.9998 26.5508 30.8415 26.5508 29.4124V21.4934H26.552C26.725 6.78768 39.138 1.456 43.3434 0.0714629C44.0902 -0.174539 44.8959 0.230931 45.1303 0.972645L45.1365 0.991188C45.3458 1.65131 45.0275 2.36089 44.3947 2.65757Z" fill="#EDF6FF"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_437_23355">
                                        <rect width="45.2" height="32" fill="white"/>
                                        </clipPath>
                                        </defs>
                                        </svg>
                                    </div>
                                    <div class="review-item__text">
                                        Разбила экран iPhone 12. 
        В Fixibot заменили за 2 часа, 
        экран как оригинальный!
                                    </div>
                                    <div class="review-item__date-quote">
                                        <div class="review-item__date">
                                            Дата 16.05.2025
                                        </div>
                                        <div class="review-item__quote">
                                            <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_437_23362)">
                                            <path d="M27.3561 29.3424C29.5928 28.2929 35.8745 24.4545 37.4108 17.2636H30.3196C28.8711 17.2636 27.6969 16.1053 27.6969 14.6763V2.58758C27.6969 1.15855 28.8711 0.000236511 30.3196 0.000236511H42.5773C44.0259 0.000236511 45.2 1.15855 45.2 2.58758V10.5066H45.1987C45.0258 25.2123 32.6128 30.544 28.4074 31.9285C27.6606 32.1745 26.8548 31.7691 26.6205 31.0274L26.6143 31.0088C26.405 30.3487 26.7233 29.6391 27.3561 29.3424Z" fill="#EDF6FF"/>
                                            <path d="M0.8053 29.3424C3.04206 28.2929 9.32377 24.4545 10.86 17.2636H3.76884C2.32028 17.2636 1.14614 16.1053 1.14614 14.6763V2.58758C1.14614 1.15855 2.32028 0.000236511 3.76884 0.000236511H16.0265C17.4751 0.000236511 18.6492 1.15855 18.6492 2.58758V10.5066H18.648C18.475 25.2123 6.06199 30.544 1.85664 31.9285C1.1098 32.1745 0.304068 31.7691 0.0697403 31.0274L0.0634727 31.0088C-0.145792 30.3487 0.172493 29.6391 0.8053 29.3424Z" fill="#EDF6FF"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_437_23362">
                                            <rect width="45.2" height="32" fill="white" transform="matrix(-1 0 0 -1 45.2 32)"/>
                                            </clipPath>
                                            </defs>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="review-item">
                                    <div class="review-item__header">
                                        <div class="review-item__name">
                                            Анна
                                            <br>34 года
                                        </div>
                                        <div class="review-item__logo fs">
                                            <img src="/img/logos/ya.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="review-item__stars">
                                        <img src="/img/stars.svg" alt="">
                                    </div>
                                    <div class="review-item__quote-top">
                                        <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_437_23355)">
                                        <path d="M17.8439 2.65757C15.6072 3.7071 9.32545 7.54546 7.78917 14.7364H14.8804C16.3289 14.7364 17.5031 15.8947 17.5031 17.3237V29.4124C17.5031 30.8415 16.3289 31.9998 14.8804 31.9998H2.62271C1.17414 31.9998 0 30.8415 0 29.4124V21.4934H0.00125308C0.174179 6.78768 12.5872 1.456 16.7926 0.0714629C17.5394 -0.174539 18.3452 0.230931 18.5795 0.972645L18.5857 0.991188C18.795 1.65131 18.4767 2.36089 17.8439 2.65757Z" fill="#EDF6FF"/>
                                        <path d="M44.3947 2.65757C42.1579 3.7071 35.8762 7.54546 34.34 14.7364H41.4312C42.8797 14.7364 44.0539 15.8947 44.0539 17.3237V29.4124C44.0539 30.8415 42.8797 31.9998 41.4312 31.9998H29.1735C27.7249 31.9998 26.5508 30.8415 26.5508 29.4124V21.4934H26.552C26.725 6.78768 39.138 1.456 43.3434 0.0714629C44.0902 -0.174539 44.8959 0.230931 45.1303 0.972645L45.1365 0.991188C45.3458 1.65131 45.0275 2.36089 44.3947 2.65757Z" fill="#EDF6FF"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_437_23355">
                                        <rect width="45.2" height="32" fill="white"/>
                                        </clipPath>
                                        </defs>
                                        </svg>
                                    </div>
                                    <div class="review-item__text">
                                        Разбила экран iPhone 12. 
        В Fixibot заменили за 2 часа, 
        экран как оригинальный!
                                    </div>
                                    <div class="review-item__date-quote">
                                        <div class="review-item__date">
                                            Дата 16.05.2025
                                        </div>
                                        <div class="review-item__quote fs">
                                            <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_437_23362)">
                                            <path d="M27.3561 29.3424C29.5928 28.2929 35.8745 24.4545 37.4108 17.2636H30.3196C28.8711 17.2636 27.6969 16.1053 27.6969 14.6763V2.58758C27.6969 1.15855 28.8711 0.000236511 30.3196 0.000236511H42.5773C44.0259 0.000236511 45.2 1.15855 45.2 2.58758V10.5066H45.1987C45.0258 25.2123 32.6128 30.544 28.4074 31.9285C27.6606 32.1745 26.8548 31.7691 26.6205 31.0274L26.6143 31.0088C26.405 30.3487 26.7233 29.6391 27.3561 29.3424Z" fill="#EDF6FF"/>
                                            <path d="M0.8053 29.3424C3.04206 28.2929 9.32377 24.4545 10.86 17.2636H3.76884C2.32028 17.2636 1.14614 16.1053 1.14614 14.6763V2.58758C1.14614 1.15855 2.32028 0.000236511 3.76884 0.000236511H16.0265C17.4751 0.000236511 18.6492 1.15855 18.6492 2.58758V10.5066H18.648C18.475 25.2123 6.06199 30.544 1.85664 31.9285C1.1098 32.1745 0.304068 31.7691 0.0697403 31.0274L0.0634727 31.0088C-0.145792 30.3487 0.172493 29.6391 0.8053 29.3424Z" fill="#EDF6FF"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_437_23362">
                                            <rect width="45.2" height="32" fill="white" transform="matrix(-1 0 0 -1 45.2 32)"/>
                                            </clipPath>
                                            </defs>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="review-item">
                                    <div class="review-item__header">
                                        <div class="review-item__name">
                                            Анна
                                            <br>34 года
                                        </div>
                                        <div class="review-item__logo">
                                            <img src="/img/logos/ya.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="review-item__quote-top">
                                        <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_437_23355)">
                                        <path d="M17.8439 2.65757C15.6072 3.7071 9.32545 7.54546 7.78917 14.7364H14.8804C16.3289 14.7364 17.5031 15.8947 17.5031 17.3237V29.4124C17.5031 30.8415 16.3289 31.9998 14.8804 31.9998H2.62271C1.17414 31.9998 0 30.8415 0 29.4124V21.4934H0.00125308C0.174179 6.78768 12.5872 1.456 16.7926 0.0714629C17.5394 -0.174539 18.3452 0.230931 18.5795 0.972645L18.5857 0.991188C18.795 1.65131 18.4767 2.36089 17.8439 2.65757Z" fill="#EDF6FF"/>
                                        <path d="M44.3947 2.65757C42.1579 3.7071 35.8762 7.54546 34.34 14.7364H41.4312C42.8797 14.7364 44.0539 15.8947 44.0539 17.3237V29.4124C44.0539 30.8415 42.8797 31.9998 41.4312 31.9998H29.1735C27.7249 31.9998 26.5508 30.8415 26.5508 29.4124V21.4934H26.552C26.725 6.78768 39.138 1.456 43.3434 0.0714629C44.0902 -0.174539 44.8959 0.230931 45.1303 0.972645L45.1365 0.991188C45.3458 1.65131 45.0275 2.36089 44.3947 2.65757Z" fill="#EDF6FF"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_437_23355">
                                        <rect width="45.2" height="32" fill="white"/>
                                        </clipPath>
                                        </defs>
                                        </svg>
                                    </div>
                                    <div class="review-item__text">
                                        Разбила экран iPhone 12. 
        В Fixibot заменили за 2 часа, 
        экран как оригинальный!
                                    </div>
                                    <div class="review-item__date-quote">
                                        <div class="review-item__date">
                                            Дата 16.05.2025
                                        </div>
                                        <div class="review-item__quote">
                                            <svg width="46" height="32" viewBox="0 0 46 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_437_23362)">
                                            <path d="M27.3561 29.3424C29.5928 28.2929 35.8745 24.4545 37.4108 17.2636H30.3196C28.8711 17.2636 27.6969 16.1053 27.6969 14.6763V2.58758C27.6969 1.15855 28.8711 0.000236511 30.3196 0.000236511H42.5773C44.0259 0.000236511 45.2 1.15855 45.2 2.58758V10.5066H45.1987C45.0258 25.2123 32.6128 30.544 28.4074 31.9285C27.6606 32.1745 26.8548 31.7691 26.6205 31.0274L26.6143 31.0088C26.405 30.3487 26.7233 29.6391 27.3561 29.3424Z" fill="#EDF6FF"/>
                                            <path d="M0.8053 29.3424C3.04206 28.2929 9.32377 24.4545 10.86 17.2636H3.76884C2.32028 17.2636 1.14614 16.1053 1.14614 14.6763V2.58758C1.14614 1.15855 2.32028 0.000236511 3.76884 0.000236511H16.0265C17.4751 0.000236511 18.6492 1.15855 18.6492 2.58758V10.5066H18.648C18.475 25.2123 6.06199 30.544 1.85664 31.9285C1.1098 32.1745 0.304068 31.7691 0.0697403 31.0274L0.0634727 31.0088C-0.145792 30.3487 0.172493 29.6391 0.8053 29.3424Z" fill="#EDF6FF"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_437_23362">
                                            <rect width="45.2" height="32" fill="white" transform="matrix(-1 0 0 -1 45.2 32)"/>
                                            </clipPath>
                                            </defs>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        
        
            </div>
        </div>
        
        <div class="faq p-100">
            <div class="container">
                <h2>
                    Ответы на частые вопросы о ремонте в Fixibot
                    <br> <span>Вопрос/ответ</span>
                </h2>
                
                <div class="row">
                    <div class="col-8">
                        <div class="faq-list" itemscope itemtype="https://schema.org/FAQPage">
                
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Сколько стоит ремонт?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>
                
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Сколько времени занимает ремонт?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>
                
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Есть ли гарантия?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>
                
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Если техника не подлежит ремонту?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Не знаю, что сломалось. Что делать?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Не знаю, что сломалось. Что делать?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Не знаю, что сломалось. Что делать?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Не знаю, что сломалось. Что делать?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>
                            <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
                                <div class="faq-question">
                                    <div itemprop="name">
                                        Не знаю, что сломалось. Что делать?
                                    </div>
                                    <div class="faq-item__btn">
                                        <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7539 8.03981L17.7539 4L15.3253 4L10.8765 8.04727L10.8765 14.0565L17.7539 8.03981Z" fill="#222222" />
                                          <path d="M4 8.03981L4 4L6.42865 4L10.8774 8.04727L10.8774 14.0565L4 8.03981Z" fill="#222222" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                                    <div class="faq-answer__in text-block" itemprop="text">
                                        Цена зависит от устройства и поломки. Например, замена экрана 
                iPhone 11 — от 3500 руб., чистка ноутбука — от 1500 руб. 
                Точную стоимость назовем после бесплатной диагностики. 
                Пишите в WhatsApp: ‪+7 (908) 119-13-74‬.
                                    </div>
                                </div>
                            </div>

                
                        </div>
                   </div>
                   <div class="col-4">
                       <div class="faq-form">
                           <form action="" class="form">
                               <h2>
                                   не нашли ответ 
                                   <br>на свой вопрос?
                               </h2>
                               <div class="faq-form__sub">
                                   Напишите нам, мы вам поможем.
                               </div>
                
                               <div class="form-group">
                                   <input type="text" name="fio" placeholder="Имя">
                               </div>
                               <div class="form-group">
                                   <input type="text" name="tel" placeholder="*Телефон">
                               </div>
                               <div class="form-group">
                                   <textarea name="question" id="" placeholder="Ваш вопрос" rows="4"></textarea>
                               </div>
                               <div class="form-group form-group__terms">
                                   <label for="term">
                                       <input type="checkbox" id="term">
                                       <div>
                                            Я выражаю Согласие на передачу и обработку персональных данных, в соответствии с Политикой конфиденциальности
                                        </div>
                                   </label>
                               </div>
                               <div class="form-group">
                                   <button type="submit" class="btn">Отправить</button>
                               </div>
                           </form>
                       </div>
                   </div>
                </div>
            </div>
        </div>
    </div>

    <div class="team p-100">
        <div class="features__circle_2"></div>
        <div class="container">
            <h2>
                Наши специалисты —
                <br> профессионалы с опытом от 5 лет
            </h2>
            <div class="team__sub">
                Каждый мастер проходит обучение для работы с новейшей техникой.
            </div>

            <div class="team-list row">
                <div class="col-3">
                    <div class="team-item">
                        <div class="team-item__photo">
                            <img src="/img/team/1.png" alt="">
                        </div>
                        <div class="team-item__content">
                            <div class="team-item__name">
                                Дмитрий
                            </div>
                            <div class="team-item__text">
                                Эксперт по ноутбукам и MacBook, ремонт материнских плат.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="team-item">
                        <div class="team-item__photo">
                            <img src="/img/team/2.png" alt="">
                        </div>
                        <div class="team-item__content">
                            <div class="team-item__name">
                                Алексей
                            </div>
                            <div class="team-item__text">
                                Мастер по смартфонам и планшетам, замена экранов, восстановление данных.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="cta">
        <div class="container">
            <div class="cta__in">
                <h2>Узнать цену за 1 минуту</h2>
                <div class="cta__form">
                    <form class="cta-search">
                        <select class="search-form__input"><option>Вид устройства</option></select>
                        <select class="search-form__input"><option>Модель</option></select>
                        <select class="search-form__input"><option>Что сломалось</option></select>
                        <button class="btn btn--orange search-form__btn">Узнать цену</button>
                    </form>
                </div>
            </div>
            <div class="cta__bot">
                <img src="/img/bot2.png" alt="">
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // 1. Получаем родительский контейнер, по которому будет двигаться мышь
        const ctaContainer = document.querySelector('.cta');
        // 2. Получаем элемент, который будет двигаться (бот)
        const botElement = document.querySelector('.cta__bot');

        if (ctaContainer && botElement) {
            // Слушаем движение мыши только внутри блока .cta
            ctaContainer.addEventListener('mousemove', function(e) {
                
                // e.offsetX / e.offsetY — это координаты мыши, 
                // отсчитанные от левого верхнего угла элемента .cta, 
                // независимо от прокрутки страницы.
                const relativeX = e.offsetX;
                const relativeY = e.offsetY;

                // Определяем центр блока .cta
                const ctaWidth = ctaContainer.offsetWidth;
                const ctaHeight = ctaContainer.offsetHeight;
                const ctaCenterX = ctaWidth / 2;
                const ctaCenterY = ctaHeight / 2;

                // Вычисляем смещение мыши относительно центра блока
                // (Центр блока теперь равен (0, 0) для нашего движения)
                const mouseX = relativeX - ctaCenterX;
                const mouseY = relativeY - ctaCenterY;

                // Определяем силу параллакса (чем больше число, тем меньше движение)
                const moveFactor = 20; 

                // Вычисляем величину сдвига для элемента бота
                const offsetX = mouseX / moveFactor;
                const offsetY = mouseY / moveFactor;
                
                // Применяем преобразование (инвертируем для эффекта "парения")
                botElement.style.transform = `translate3d(${-offsetX}px, ${-offsetY}px, 0)`; 
            });

            // Дополнительно: Сбрасываем позицию бота в центр (0,0), когда мышь покидает блок .cta
            ctaContainer.addEventListener('mouseleave', function() {
                botElement.style.transform = 'translate3d(0, 0, 0)';
            });
        }
    });
    </script>

    <div class="callback m-100">
        <div class="container">
            <div class="callback__in card">
                <div class="callback__header">
                    <h2>
                        проконсультируем
                        <br>прямо сейчас
                    </h2>
                    <div class="callback__sub">
                        Позвоните или напишите нам, мы онлайн.
                    </div>
                </div>
                <div class="callback__buttons">
                    <div class="callback__main">
                        <a class="" href="#" data-toggle="modal" data-target="#callback-modal">
                            <svg class="fs" width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.86377 16.3701C11.7646 17.2394 14.0416 17.7578 16.7578 17.7578V13.5684L12.8184 12.521L9.86377 16.3701ZM9.86377 16.3701C6.08091 14.6398 3.78125 11.5208 2.47729 8.33154M2.47729 8.33154C1.39395 5.68381 1 2.9879 1 1H4.93945L5.92432 5.18945L2.47729 8.33154Z" stroke="#008EE9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            Позвонить
                        </a>
                    </div>
                    <div class="callback__social">
                        <a href="" class="social-vk">
                            <svg class="fs" width="30" height="18" viewBox="0 0 30 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M0 0C0.243598 11.2432 6.08994 18 16.3398 18H16.9207V11.5676C20.6871 11.9279 23.5353 14.5766 24.6783 18H30C28.5384 12.8829 24.6971 10.0541 22.2986 8.97297C24.6971 7.63964 28.07 4.3964 28.8757 0H24.0412C22.9919 3.56757 19.8813 6.81081 16.9207 7.11712V0H12.0862V12.4685C9.08807 11.7477 5.30294 8.25225 5.13429 0H0Z" fill="white"/>
                            </svg>
                        </a>
                        <a href="" class="social-wa">
                            <svg class="fs" width="31" height="30" viewBox="0 0 31 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 30L3.10875 22.2962C1.8075 20.0413 1.12375 17.485 1.125 14.8637C1.12875 6.66875 7.7975 0 15.9913 0C19.9675 0.00125 23.7 1.55 26.5075 4.36C29.3137 7.17 30.8588 10.905 30.8575 14.8775C30.8538 23.0738 24.185 29.7425 15.9913 29.7425C13.5037 29.7413 11.0525 29.1175 8.88125 27.9325L1 30ZM9.24625 25.2413C11.3412 26.485 13.3412 27.23 15.9862 27.2313C22.7962 27.2313 28.3438 21.6887 28.3475 14.875C28.35 8.0475 22.8288 2.5125 15.9963 2.51C9.18125 2.51 3.6375 8.0525 3.635 14.865C3.63375 17.6462 4.44875 19.7287 5.8175 21.9075L4.56875 26.4675L9.24625 25.2413ZM23.48 18.4113C23.3875 18.2563 23.14 18.1637 22.7675 17.9775C22.3963 17.7913 20.57 16.8925 20.2287 16.7687C19.8888 16.645 19.6413 16.5825 19.3925 16.955C19.145 17.3263 18.4325 18.1637 18.2162 18.4113C18 18.6588 17.7825 18.69 17.4112 18.5037C17.04 18.3175 15.8425 17.9263 14.4237 16.66C13.32 15.675 12.5737 14.4587 12.3575 14.0863C12.1412 13.715 12.335 13.5138 12.52 13.3288C12.6875 13.1625 12.8912 12.895 13.0775 12.6775C13.2662 12.4625 13.3275 12.3075 13.4525 12.0588C13.5763 11.8113 13.515 11.5938 13.4213 11.4075C13.3275 11.2225 12.585 9.39375 12.2762 8.65C11.9738 7.92625 11.6675 8.02375 11.44 8.0125L10.7275 8C10.48 8 10.0775 8.0925 9.7375 8.465C9.3975 8.8375 8.4375 9.735 8.4375 11.5638C8.4375 13.3925 9.76875 15.1587 9.95375 15.4062C10.14 15.6537 12.5725 19.4062 16.2987 21.015C17.185 21.3975 17.8775 21.6262 18.4163 21.7975C19.3062 22.08 20.1163 22.04 20.7563 21.945C21.47 21.8387 22.9538 21.0462 23.2638 20.1787C23.5738 19.31 23.5738 18.5662 23.48 18.4113Z" fill="white"/>
                            </svg>
                        </a>
                        <a href="" class="social-tg">
                            <svg class="fs" width="32" height="26" viewBox="0 0 32 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1.92638 11.3251C1.92638 11.3251 15.837 5.6101 20.6623 3.60044C22.5149 2.79448 28.7847 0.219602 28.7847 0.219602C28.7847 0.219602 31.6736 -0.910833 31.4328 1.83152C31.3491 2.96195 30.7106 6.89754 30.0616 11.1576C29.0987 17.1866 28.052 23.7808 28.052 23.7808C28.052 23.7808 27.895 25.6335 26.5238 25.9475C25.1526 26.2719 22.9022 24.8275 22.5045 24.503C22.18 24.2623 16.4755 20.6407 14.3821 18.8718C13.8169 18.3903 13.1784 17.4273 14.4658 16.2969C17.3547 13.6487 20.8193 10.3516 22.9022 8.25825C23.8652 7.29529 24.8281 5.04488 20.8088 7.77677C15.1043 11.7124 9.47307 15.4177 9.47307 15.4177C9.47307 15.4177 8.18563 16.2236 5.77823 15.5014C3.37082 14.7792 0.555199 13.8162 0.555199 13.8162C0.555199 13.8162 -1.37073 12.6125 1.92638 11.3251Z" fill="white"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>в
    </div>

    <div class="video m-100">
        <div class="container">
            <div class="row auto-h">
                <div class="col-4">
                    <div class="video__blue">
                        Ремонт с Fixibot — это просто.
                        <br><span>Как мы работаем</span>
                    </div>
                </div>
                <div class="col-8">
                    <div class="video__in">
                        <img src="/img/video.jpg" alt="">
                        <button class="video__btn">
                            <svg width="63" height="63" viewBox="0 0 63 63" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_4005_1725)">
                            <path d="M60.5246 19.2387C58.9383 15.4877 56.667 12.1188 53.7741 9.22653C50.8819 6.33431 47.5129 4.06307 43.762 2.47604C39.8774 0.833028 35.7524 0 31.5003 0C27.2483 0 23.1233 0.833028 19.2387 2.47604C15.4877 4.06241 12.1188 6.33365 9.22653 9.22653C6.33431 12.1188 4.06307 15.4877 2.47604 19.2387C0.833028 23.1226 0 27.2483 0 31.5003C0 35.7524 0.833028 39.878 2.47604 43.762C4.06241 47.5129 6.33365 50.8819 9.22653 53.7741C12.1188 56.6664 15.4877 58.9376 19.2387 60.5246C23.1226 62.1676 27.2483 63.0007 31.5003 63.0007C35.7524 63.0007 39.8774 62.1676 43.762 60.5246C47.5129 58.9383 50.8819 56.667 53.7741 53.7741C56.6664 50.8819 58.9376 47.5129 60.5246 43.762C62.1676 39.878 63.0007 35.7524 63.0007 31.5003C63.0007 27.2483 62.1676 23.1233 60.5246 19.2387Z" fill="white"/>
                            </g>
                            <g clip-path="url(#clip1_4005_1725)">
                            <path d="M60.5246 19.2387C58.9382 15.4877 56.667 12.1188 53.7741 9.22653C50.8819 6.33431 47.5129 4.06307 43.762 2.47604C39.8774 0.833028 35.7524 0 31.5003 0C27.2483 0 23.1233 0.833028 19.2387 2.47604C15.4877 4.06241 12.1188 6.33365 9.22653 9.22653C6.33431 12.1188 4.06307 15.4877 2.47604 19.2387C0.833028 23.1226 0 27.2483 0 31.5003C0 35.7524 0.833028 39.878 2.47604 43.762C4.06241 47.5129 6.33365 50.8819 9.22653 53.7741C12.1188 56.6664 15.4877 58.9376 19.2387 60.5246C23.1226 62.1676 27.2483 63.0007 31.5003 63.0007C35.7524 63.0007 39.8774 62.1676 43.762 60.5246C47.5129 58.9382 50.8819 56.667 53.7741 53.7741C56.6664 50.8819 58.9376 47.5129 60.5246 43.762C62.1676 39.878 63.0007 35.7524 63.0007 31.5003C63.0007 27.2483 62.1676 23.1233 60.5246 19.2387ZM45.0132 34.2404L25.7323 48.1405C23.4986 49.7512 20.3799 48.155 20.3799 45.4004V17.5996C20.3799 14.8457 23.4986 13.2494 25.7323 14.8595L45.0132 28.7596C46.8827 30.1076 46.8827 32.8911 45.0132 34.2391V34.2404Z" fill="#11B8EC"/>
                            <path opacity="0.1" d="M59.7906 19.4643C58.2437 15.8075 56.0291 12.5235 53.2093 9.70306C50.3895 6.88327 47.1055 4.66933 43.4487 3.12246C39.6622 1.52094 35.64 0.708984 31.4946 0.708984C27.3492 0.708984 23.3276 1.52094 19.5405 3.12246C15.8837 4.66933 12.5997 6.88327 9.77989 9.70306C6.9601 12.5235 4.7455 15.8075 3.19863 19.4643C1.59711 23.2508 0.785156 27.273 0.785156 31.4184C0.785156 35.5638 1.57209 39.4603 3.12488 43.1948C7.56199 37.3807 13.6461 32.8823 20.3768 29.7596V17.5994C20.3768 14.8454 23.4956 13.2492 25.7293 14.8593L39.194 24.5665C46.5029 23.6413 53.9653 23.7091 61.3532 24.205C60.9641 22.5903 60.4425 21.0079 59.7892 19.4643H59.7906Z" fill="white"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_4005_1725">
                            <rect width="63.0007" height="63.0007" fill="white"/>
                            </clipPath>
                            <clipPath id="clip1_4005_1725">
                            <rect width="63.0007" height="63.0007" fill="white"/>
                            </clipPath>
                            </defs>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="cta2 m-100">
        <div class="container">
            <div class="cta2__in">
                <div class="row">
                    <div class="col-4">
                        <h2>
                            Найди 
                            <br>неисправность 
                            <br>по симптомам
                        </h2>
                    </div>
                    <div class="col-8">
                        <div class="cta__form">
                            <form class="">
                                <select class="search-form__input"><option>Вид устройства</option></select>
                                <select class="search-form__input"><option>Модель</option></select>
                                <select class="search-form__input"><option>Что сломалось</option></select>
                                <button class="btn btn--orange search-form__btn">Узнать причину</button>
                            </form>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <div class="map">
        <div class="container">
            <h2>
                Расположение сервисного центра
                <br><span>Fixibot в Омске</span>
            </h2>

            <div class="map-container">
                <div class="map-info">
                    <div class="map-item">
                        <div class="map-item__title">
                            Адрес:
                        </div>
                        <div class="map-item__value">
                            ул. 6-я Станционная, 2 к 2
                            <br> ТК Пароплаза, 2-й этаж
                        </div>
                    </div>
                    <div class="map-item">
                        <div class="map-item__value">
                            Ежедневно с 10:00 до 20:00
                        </div>
                    </div>
                    <div class="map-item">
                        <div class="map-item__value">
                             +7 (495)47-81-80
                        </div>
                    </div>
                    <div class="map-item map-item_phone">
                        <div class="map-item__value">
                            <div class="map-item__social">
                                <a href="">
                                    <svg width="18" height="15" viewBox="0 0 18 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M1.10112 6.48381C1.10112 6.48381 9.0645 3.21217 11.8268 2.0617C12.8874 1.60032 16.4766 0.126285 16.4766 0.126285C16.4766 0.126285 18.1304 -0.520852 17.9926 1.04905C17.9447 1.69619 17.5791 3.94919 17.2076 6.38794C16.6564 9.83933 16.0572 13.6143 16.0572 13.6143C16.0572 13.6143 15.9673 14.6749 15.1823 14.8546C14.3974 15.0404 13.1091 14.2135 12.8814 14.0278C12.6957 13.8899 9.43001 11.8167 8.23161 10.804C7.90804 10.5284 7.54253 9.97715 8.27954 9.33001C9.93334 7.81403 11.9167 5.92655 13.1091 4.72815C13.6604 4.17688 14.2116 2.8886 11.9107 4.45252C8.64506 6.70551 5.42136 8.82668 5.42136 8.82668C5.42136 8.82668 4.68434 9.28807 3.30618 8.87462C1.92801 8.46117 0.316163 7.90991 0.316163 7.90991C0.316163 7.90991 -0.786366 7.22083 1.10112 6.48381Z" fill="#008EE9" />
                                    </svg>
                                </a>
                                <span>|</span>
                                <a href="">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M0 16L1.12467 11.8913C0.430667 10.6887 0.066 9.32533 0.0666667 7.92733C0.0686667 3.55667 3.62533 0 7.99533 0C10.116 0.000666667 12.1067 0.826667 13.604 2.32533C15.1007 3.824 15.9247 5.816 15.924 7.93467C15.922 12.306 12.3653 15.8627 7.99533 15.8627C6.66867 15.862 5.36133 15.5293 4.20333 14.8973L0 16ZM4.398 13.462C5.51533 14.1253 6.582 14.5227 7.99267 14.5233C11.6247 14.5233 14.5833 11.5673 14.5853 7.93333C14.5867 4.292 11.642 1.34 7.998 1.33867C4.36333 1.33867 1.40667 4.29467 1.40533 7.928C1.40467 9.41133 1.83933 10.522 2.56933 11.684L1.90333 14.116L4.398 13.462ZM11.9893 9.81933C11.94 9.73667 11.808 9.68733 11.6093 9.588C11.4113 9.48867 10.4373 9.00933 10.2553 8.94333C10.074 8.87733 9.942 8.844 9.80933 9.04267C9.67733 9.24067 9.29733 9.68733 9.182 9.81933C9.06667 9.95133 8.95067 9.968 8.75267 9.86867C8.55467 9.76933 7.916 9.56067 7.15933 8.88533C6.57067 8.36 6.17267 7.71133 6.05733 7.51267C5.942 7.31467 6.04533 7.20733 6.144 7.10867C6.23333 7.02 6.342 6.87733 6.44133 6.76133C6.542 6.64667 6.57467 6.564 6.64133 6.43133C6.70733 6.29933 6.67467 6.18333 6.62467 6.084C6.57467 5.98533 6.17867 5.01 6.014 4.61333C5.85267 4.22733 5.68933 4.27933 5.568 4.27333L5.188 4.26667C5.056 4.26667 4.84133 4.316 4.66 4.51467C4.47867 4.71333 3.96667 5.192 3.96667 6.16733C3.96667 7.14267 4.67667 8.08467 4.77533 8.21667C4.87467 8.34867 6.172 10.35 8.15933 11.208C8.632 11.412 9.00133 11.534 9.28867 11.6253C9.76333 11.776 10.1953 11.7547 10.5367 11.704C10.9173 11.6473 11.7087 11.2247 11.874 10.762C12.0393 10.2987 12.0393 9.902 11.9893 9.81933Z" fill="#008EE9" />
                                    </svg>
                                </a>
                            </div>

                            <a href="tel:+7 (908) 119-13-74">+7 (908) 119-13-74</a>
                        </div>
                    </div>

                    <div class="map__actions">
                        <button class="btn">
                            Закать выезд мастера
                        </button>
                        <button class="btn btn_ghost">
                            Закать доставку техники
                        </button>
                    </div>
                </div>
                <div class="map__frame">
                    <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A94ade426cbd00d8120e59cd2fc24125d575addf5848e8cf886c5723002e3ba14&amp;source=constructor&scroll=false" width="100%" height="600" frameborder="0"></iframe>
                </div>
            </div>
        </div>
    </div>

</div>


<?php get_footer(); ?>
